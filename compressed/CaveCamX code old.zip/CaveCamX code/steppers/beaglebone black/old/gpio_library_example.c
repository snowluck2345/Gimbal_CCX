// gpio_library_example.c
// illuminates an LED connected to a gpio pin with gpio library functions
// use expansion header P8, pin8
// GPIO2_3 designated as gpio 67
#include <robotics_cape.h>
#define PIN 46
int main (void){
// export gpio pin for use
if(gpio_export(PIN)){
printf("Unable to open export.\n");
return -1;
}
// set pin for output
if(gpio_set_dir(PIN, OUTPUT_PIN)){
printf("Unable to open gpio67_direction.\n");
return -1;
}
// start blinking loop
printf("blinking LED\n");
int i = 0;
while(i<10){
// turn pin on
gpio_set_value(PIN, 1);
printf("ON\n");
sleep(1);
// turn pin off
gpio_set_value(PIN, 0);
printf("OFF\n");
i++; // increment counter
sleep(1);
}
return 1;
}