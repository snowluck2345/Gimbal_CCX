#include <robotics_cape.h>



//CONSTANTS
#define YAW_PULSE_PIN 67
#define YAW_DIRECTION_PIN 66
#define PITCH_PULSE_PIN 67
#define PITCH_DIRECTION_PIN 66
#define ACCELERATION_CONSTANT_YAW 3.5
#define ACCELERATION_CONSTANT_PITCH 5
#define STEP_SIZE_YAW 0.00785398163 //radians
#define STEP_SIZE_PITCH 0.00785398163 //radians

//GLOBAL DECLARATIONS
int32_t goal_position[2]; //pan, tilt
int32_t current_position[2]; //pan, tilt
int32_t steps_to_move[2]; //pan, tilt; negative or positive to determine direction-->negative=cc, postive=c

//FUNCTION DECLARATIONS
int micro_acceleration_delay(double step_theta, double acceleration_constant, int step_number);
void calculate_steps_to_move(int32_t *goal_position_cpy, int32_t *current_position_cpy);
int gpio_setup(void);

int main (void){

	int setup_success = gpio_setup();

	int direction = 0;
	int i = 0;
	int acceleration_flag;
	goal_position[0] = 0;
	goal_position[1] = 0;
	current_position[0] = 0;
	current_position[1] = 0;

	while(true)
	{
		printf("input goal position, 0-800:");
		scanf("%d", &goal_position[0]);
		goal_position[0] = goal_position[0] % 800;

	
		calculate_steps_to_move(goal_position, current_position);


		printf("Steps to move: %d\n", steps_to_move[0]);

		while(current_position[0] != goal_position[0])
		{
			
			if(i <= abs(steps_to_move[0]/2) && acceleration_flag == 0)
			{
				i++;
			}
			else
				if(i > 0)
				{
					i--;
					acceleration_flag = 1;
				}
			int delay = micro_acceleration_delay(STEP_SIZE_YAW, ACCELERATION_CONSTANT_YAW, i);
			if(delay < 650)
				delay = 650;
			printf("%d, %d, %d, %d, %d\n", delay, i, steps_to_move[0], current_position[0], goal_position[0]);

			if(steps_to_move[0] > 0)
			{
				current_position[0]++;
				gpio_set_value(YAW_DIRECTION_PIN, 0);
				gpio_set_value(YAW_PULSE_PIN, 1);
				usleep(50);
				gpio_set_value(YAW_PULSE_PIN, 0);
			}
			if(steps_to_move[0] < 0)
			{
				current_position[0]--;
				gpio_set_value(YAW_DIRECTION_PIN, 1);
				gpio_set_value(YAW_PULSE_PIN, 1);
				usleep(50);
				gpio_set_value(YAW_PULSE_PIN, 0);
			}
			if(current_position[0] < 0)
				current_position[0] = 800 + current_position[0];
			if(current_position[0] >= 800)
				current_position[0] = current_position[0] - 800;
			usleep(delay);
		}

		i = 0;
		acceleration_flag = 0;

		
	}
}

int micro_acceleration_delay(double step_theta, double acceleration_constant, int step_number)
{
	//step_theta is theta per step or microstep
	//acceleration constant is radians/s^2
	//step_number is delay calculation for the step I am interested in calculating

	double delay_seconds = sqrt(2*step_theta/acceleration_constant) * (sqrt(step_number + 1) - sqrt(step_number));
	int delay_microseconds = (int)(delay_seconds * 1000000);

	return delay_microseconds;
}

void calculate_steps_to_move(int32_t *goal_position_cpy, int32_t *current_position_cpy)
{
	steps_to_move[0] = goal_position_cpy[0] - current_position_cpy[0];
	if(steps_to_move[0] > 400)
	{
		steps_to_move[0] = steps_to_move[0] - 800;
	}
	if(steps_to_move[0] < -400)
	{
		steps_to_move[0] = steps_to_move[0] + 800;
	}
	
	steps_to_move[1] = goal_position_cpy[1] - current_position_cpy[1];
	
}

int gpio_setup(void)
{
	if(gpio_export(YAW_PULSE_PIN)){
		printf("Unable to open export.\n");
		return -1;
	}

	// set pin for output
	if(gpio_set_dir(YAW_PULSE_PIN, OUTPUT_PIN)){
		printf("Unable to open gpio67_direction.\n");
		return -1;
	}

	if(gpio_export(YAW_DIRECTION_PIN)){
		printf("Unable to open export.\n");
		return -1;
	}

	// set pin for output
	if(gpio_set_dir(YAW_DIRECTION_PIN, OUTPUT_PIN)){
		printf("Unable to open gpio67_direction.\n");
		return -1;
	}

	return 0;
}