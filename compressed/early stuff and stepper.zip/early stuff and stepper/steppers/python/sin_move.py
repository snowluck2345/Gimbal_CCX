import serial
import math
import time

def move(yaw,pitch):
	s.write('$1,%s,%snn'%(yaw,pitch))

s = serial.Serial('COM6', baudrate = 9600)

bob='00300'

#s.write('$1,00000,%snn'%bob)

time.sleep(1)

while True:
	move('00000','00000')
	time.sleep(3)
	move('01000','00500')
	time.sleep(3)
	print 'hi'
