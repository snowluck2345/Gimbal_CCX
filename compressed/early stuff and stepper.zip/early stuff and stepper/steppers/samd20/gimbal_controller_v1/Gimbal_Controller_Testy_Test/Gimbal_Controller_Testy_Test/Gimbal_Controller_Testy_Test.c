/*
 * Gimbal_Controller_Testy_Test.c
 *
 * Created: 4/4/2015 6:57:42 PM
 *  Author: Dimitri
 */ 

#include "sam.h"

/**
 * \brief Application entry point.
 *
 * \return Unused (ANSI-C compatibility).
 */
int main(void)
{
    /* Initialize the SAM system */
    SystemInit();

    while (1) 
    {
        //TODO:: Please write your application code 
    }
}
