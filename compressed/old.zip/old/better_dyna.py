# -- must be run as root


import time
import serial
import Adafruit_BBIO.UART as UART
import Adafruit_BBIO.GPIO as GPIO




# -------------- control table (decimal) ---------


MODELNUMBER_L = 0
MODELNUMBER_H = 1
VERSIONOFFIRMWARE = 2
ID = 3
BAUDRATE = 4
RETURNDELAYTIME = 5
CWANGLELIMIT_L = 6
CWANGLELIMT_H = 7
CCWANGLELIMIT_L = 8
CCWANGLELIMIT_H = 9
THEHIGHESTLIMITTEMPERATURE  = 11
THELOWESTLIMITVOLTAGE = 12
THEHIGHESTLIMITVOLTAGE = 13
MAXTORQUE_L = 14
MAXTORQUE_H = 15
STATUSRETURNLEVEL = 16
ALARMLED = 17
ALARMSHUTDOWN = 18
DOWNCALIBRATION_L = 20
DOWNCALIBRATION_H = 21
UPCALIBRATION_L = 22
UPCALIBRATION_H = 23
TORQUEENABLE = 24
LED = 25
CWCOMPLIANCEMARGIN = 26
CCWCOMPLIANCEMARGIN = 27
CWCOMPLIANCESLOPE = 28
CCWCOMPLIANCESLOPE = 29
GOALPOSITION_L = 30
GOALPOSITION_H = 31
MOVINGSPEED_L = 32
MOVINGSPEED_H = 33
TORQUELIMIT_L = 34
TORQUELIMIT_H = 35
PRESENTPOSITION_L = 36
PRESENTPOSITION_H = 37
PRESENTSPEED_L = 38
PRESENTSPEED_H = 39
PRESENTLOAD_L = 40
PRESENTLOAD_H = 41
PRESENTVOLTAGE = 42
PRESENTTEMPERATURE = 43
REGISTEREDINSTRUCTION = 44
MOVING = 46
LOCK = 47
PUNCH_L = 48
PUNCH_H = 49


# ---------------------------------------------------------




# -------------- instructions ---------


PING = 1
READDATA = 2
WRITEDATA = 3
REGWRITE= 4
ACTION = 5
RESET = 6
SYNCWRITE= 7


# ---------------------------------------------------------




# -------------- uart configurable settings ---------


# settings for UART2
DISPLAYPORT = '/dev/ttyO2'
RX_MUX = 'spi0_sclk'
TX_MUX = 'spi0_d0'
MUX_MODE = 1
TIMEOUT = 1
SPEED=  115200


# MUX settings
RECEIVE_ENABLE = 32


# ---------------------------------------------------------



UART.setup("UART2")


#initialize uart
ser = serial.Serial(DISPLAYPORT, SPEED, timeout=TIMEOUT)
ser.open()

# ---------------------------------------------------------

GPIO.setup("P8_3", GPIO.OUT)
GPIO.output("P8_3", GPIO.LOW)


# -------------- sevo functions ---------
print "hi"

def servo_write(servoId, instruction, parameters):
	GPIO.output("P8_3", GPIO.HIGH)
	ser.write("\xFF") #0xFF
	ser.write("\xFF") #0xFF
	ser.write(chr(servoId)) #servo ID
	ser.write(chr(len(parameters) + 2)) #number of parameters
	ser.write(chr(instruction)) #instruction
	parameters_total = 0
	for i in parameters: #write parameters (starting address first)
 		ser.write(chr(i))
		parameters_total += i
		#checksum (missing overflow handler code)
		ser.write(chr(~(servoId + (len(parameters) + 2) + instruction + parameters_total) & 0xFF))
		GPIO.output("P8_3", GPIO.LOW)
# ---------------------------------------------------------

print "hi"



servo_write(1, WRITEDATA, (LED, 1))
time.sleep(1)
servo_write(1, WRITEDATA, (LED, 0))
time.sleep(1)

print "hi"

# cleanup - remove GPIO38 folder from file system
GPIO.cleanup()
ser.close
print "done"

