#!/usr/bin/env python

"""QX1 interfacing code for python"""

import json
import requests
import threading
import time

from gevent import monkey
from gevent.monkey import patch_all; patch_all()
from flask import Flask, render_template, Response, jsonify
from gevent import wsgi

#cam_url = 'http://10.0.0.1:10000/sony/camera'
cam_url = "http://192.168.122.1:8080/sony/camera"
av_url = "http://192.168.122.1:8080/sony/avContent"

class LiveviewThread(threading.Thread):
    running = True
    def __init__(self):
        print "Initializing..."
        threading.Thread.__init__(self)
        self.running = True
        self.jpg = None
    def run(self):
        print "Starting liveview..."
        self.running = True
        s = start_liveview()
        print s
        data = open_stream(s)
        #print data
        while self.running:
            jpg = decode_frame(data)
            if jpg is not None:
                self.jpg = jpg
            else:
                continue
    def stop_running(self):
        print "Stopping liveview..."
        self.running = False
        stop_liveview()
    def get_jpg(self):
        return self.jpg


def get_payload(method, params):
    if (method == "getContentList"):
        return {
        "method": method,
        "params": params,
        "id": 1,
        "version": "1.3"
        }
    elif (method == "getContentCount"):
        return {
        "method": method,
        "params": params,
        "id": 1,
        "version": "1.2"
        }
    else:
        return {
    	"method": method,
    	"params": params,
    	"id": 1,
    	"version": "1.0"
        }

def sony_api_call(action, params):
    payload = get_payload(action, params)
    headers = {'Content-Type': 'application/json'}
    response = requests.post(cam_url, data=json.dumps(payload), headers=headers)
    return response.json()['result']

def sony_api_call_contents(action, params):
    payload = get_payload(action, params)
    headers = {'Content-Type': 'application/json'}
    response = requests.post(av_url, data=json.dumps(payload), headers=headers)
    return response.json()['result']

# getEvent (v1.0)
# params: [ boolean ]
# returns: [{"key1":"value1"}, {"key2":"value2"}, {"key3":"value3"}, ... ]
def get_event():
    return sony_api_call("getEvent", [False])

        ################
        ### Exposure ###
        ################
# getExposureMode (v1.0)
# params: []
# returns: [ "string" ]
def get_exposure_mode():
    return sony_api_call("getExposureMode", [])

# setExposureMode (v1.0)
# params: [ "string" ]
# returns: [ int ], int = 0 if successful
def set_exposure_mode(mode):
    return sony_api_call("setExposureMode", [mode])

        ################
        ### Aperture ###
        ################
# getFNumber (v1.0)
# params: []
# returns: [ "string" ]
def get_aperture():
    return sony_api_call("getFNumber", [])[0]

# getAvailableFNumber (v1.0)
# params: []
# returns: [ "string", ["string1", "string2", ...] ]
def get_avail_aperture():
    return sony_api_call("getAvailableFNumber", [])

# setFNumber (v1.0)
# params: [ "string" ]
# returns: [ int ], int = 0 if successful
def set_aperture(aperture):
    sony_api_call("setFNumber", [aperture])

        ################
        ### Shutter ###
        ################
# getShutterSpeed (v1.0)
# params: []
# returns: [ "string" ]
def get_shutter():
    return sony_api_call("getShutterSpeed", [])[0]

# getAvailableShutterSpeed (v1.0)
# params: []
# returns: [ "string", ["string1", "string2", ...]]
def get_avail_shutter():
    return sony_api_call("getAvailableShutterSpeed", [])

# setShutterSpeed (v1.0)
# params: [ "string" ]
# returns: [ int ], int = 0 if successful
def set_shutter(shutter):
    sony_api_call("setShutterSpeed", [shutter])

        ################
        ##### ISO #####
        ################
# getIsoSpeedRate (v1.0)
# params: []
# returns: [ "string" ]
def get_iso():
    return sony_api_call("getIsoSpeedRate", [])

# getAvailableIsoSpeedRate (v1.0)
# params: []
# returns: [ "string", ["string1", "string2",...]]
def get_avail_iso():
    return sony_api_call("getAvailableIsoSpeedRate", [])

# setIsoSpeedRate (v1.0)
# params: [ "string" ]
# returns: [ int ], int = 0 if successful
def set_iso(iso):
    sony_api_call("setIsoSpeedRate", [iso])

        ################
        ### Picture ###
        ################
# actTakePicture (v1.0)
# params: []
# returns: [ ["string"] ]
def take_picture():
    return str(sony_api_call("actTakePicture", [])[0][0])

def await_take_pic():
    return str(sony_api_call("awaitTakePicture", [])[0][0])

def get_picture(url, filename):
    response = requests.get(url)
    chunk_size = 1024
    with open(filename, 'wb') as fd:
	for chunk in response.iter_content(chunk_size):
	    fd.write(chunk)

        ################
        #### Focus ####
        ################
# setTouchAFPosition (v1.0)
# params: [ double, double ]
# returns: [ int, {"key1": boolean, "key2": "string"} ]
def set_focus(xaxis, yaxis):
    sony_api_call("setTouchAFPosition", [xaxis, yaxis])

# getAvailabeFocusMode (v1.0)
# params: []
# returns: [ "string", ["string1", "string2"] ]
def get_focus_mode():
    return sony_api_call("getAvailableFocusMode",[])

# setFocusMode (v1.0)
# params: [ "string" ]
# returns: [ int ], int = 0 if successful
def set_focus_mode(focus_mode):
    sony_api_call("setFocusMode", [focus_mode])

        ################
        ##### Mode #####
        ################
# setcameraFunction (v1.0)
# params: [ "string" ]
# returns: [ int ], int = 0 if successful
def set_camera_function(function):
    sony_api_call("setCameraFunction", [function])

# getCameraFunction (v1.0)
# params: []
# returns: [ "string" ]
def get_camera_function():
    return sony_api_call("getCameraFunction", [])[0]

        ################
        ### Contents ###
        ################
# getSourceList (v1.0)
# params: ["string"]
# returns: [ [ {"key1":"string1"} ] ]
def get_source_list():
    return sony_api_call_contents("getSourceList", [{"scheme": "storage"}])

# getStorageInformation (v1.0)
# params: []
# returns: [ ["key1":"string1", "key2": "string2", ...] ]
def get_storage_information():
    return sony_api_call("getStorageInformation", [])

# getContentList (v1.3)
# params: [ {"key1":"string1", "key2":int , "key3":int, "key4":"string", "key5":"string"} ]
# returns: [ [ {"key1":"string1", "key2":"string1", ...} ] ]
def get_content_list(start_index, elements):
    return sony_api_call_contents("getContentList", [{"uri": "storage:memoryCard1", "stIdx": start_index, "cnt": elements, "view": "flat", "sort": ""}])[0]

def get_content_count():
    return sony_api_call_contents("getContentCount", [{"uri": "storage:memoryCard1", "view": "flat"}])

	
### LIVEVIEW STUFF
def start_liveview():
    response = sony_api_call("startLiveview", [])
    url = str(response[0])
    return url

def stop_liveview():
    sony_api_call("stopLiveview", [])

def open_stream(url):
    return requests.get(url, stream=True)

def decode_frame(data):
    #this url is live view data specific

    # decode packet header
    start = ord(data.raw.read(1))
    #below very expensive, context switching, do a while loop instead, blocking until good data
    if(start != 0xFF):
	print 'bad start byte\nexpected 0xFF got %x'%start
	return # get rid of this, maybe, low prioritiy to remove
    pkt_type = ord(data.raw.read(1))
    if(pkt_type != 0x01):
	print 'not a liveview packet'
	return 
    frameno = int(data.raw.read(2).encode('hex'), 16)
    timestamp = int(data.raw.read(4).encode('hex'), 16)

    # decode liveview header
    start = int(data.raw.read(4).encode('hex'), 16)
    if(start != 0x24356879):
	print 'expected 0x24356879 got %x'%start
	return
    jpg_size = int(data.raw.read(3).encode('hex'), 16)
    pad_size = ord(data.raw.read(1))
    # read out the reserved header
    data.raw.read(4)

    fixed_byte = ord(data.raw.read(1))
    if(fixed_byte is not 0x00):
	print 'expected 0x00 got %x'%fixed_byte
	return 

    data.raw.read(115)

    # read out the jpg
    jpg_data = data.raw.read(jpg_size)
    data.raw.read(pad_size)
    return jpg_data

# initialization    
app = Flask(__name__)
LVthread = LiveviewThread()
LVthread.start()
set_focus_mode("AF-S")  # "MF" does not work with liveview focusing
storage = get_storage_information()[0][0]['storageID']
content_list = ['Loading...']
large_content = []
content_count = 0
current_function = "Remote Shooting"

@app.route('/')
def index():
    return render_template('index.html')

def gen():
    global LVthread
    while True:
        jpg = LVthread.get_jpg()
        if jpg is not None:
            yield (b'--frame\r\n'
                    b'Content-Type: image/jpeg\r\n\r\n' + LVthread.get_jpg() + b'\r\n')

@app.route('/feed')
def feed():
    return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=frame')

saving_URL = 'no URL';
@app.route('/takePicture')
def take_picture_cb():
	global saving_URL 
	saving_URL = take_picture()
	print saving_URL;

@app.route('/setMode/<mode>')
def set_mode_cb(mode=None):
    set_exposure_mode(mode)

@app.route('/setAperture/<aperture>')
def set_aperture_cb(aperture=None):
    set_aperture(aperture)

@app.route('/setShutter/<shutter>')
def set_shutter_cb(shutter=None):
    shutter = shutter.replace('.', '/')
    set_shutter(shutter)

@app.route('/setISO/<iso>')
def set_iso_cb(iso=None):
    set_iso(iso)

@app.route('/setFocus/<position>')
def set_focus_cb(position=None):
    position = position.split(',')
    set_focus(float(position[0]), float(position[1]))

@app.route('/setCameraFunction/<camera_function>')
def set_camera_function_cb(camera_function=None):
    global LVthread
    global current_function
    global content_list
    global large_content
    global content_count
    if ((camera_function == "Contents Transfer")):
        print "Contents Transfer Mode"
        # first stop liveview
        LVthread.stop_running()

        global storage
        # check if media inserted
        if (storage == "No Media"):
            print "NO SD CARD"
            content_list = ["No SD card found"]
        else:
            # set camera mode
            set_camera_function(camera_function)
            time.sleep(6)
            current_function = camera_function

            # get number of images on SD card
            content_count = get_content_count()[0]['count']

            if (content_count == 0):
                content_list = ["SD card is empty."]
            else:
                # grab contents in batches of 100
                URL_list = []
                num_loops = content_count/100
                remainder = content_count % 100

                # if less than 100 images
                if ((num_loops < 1) and (remainder > 0)):
                    URL_list = get_content_list(0, remainder)
                else:
                    # grab in batch
                    for loop in range(0, num_loops):
                        item_list = get_content_list(loop*100, 100)
                        for item in item_list:
                            URL_list.append(item)
                    # grab remainder
                    item_list = get_content_list(num_loops*100, remainder)
                    for item in item_list:
                            URL_list.append(item)

                # grab smallURL and largeURL
                content_list = []
                for image in URL_list:
                    content_list.append(image["content"]["smallUrl"])
                    large_content.append(image["content"]["largeUrl"])
    elif ((camera_function == "Remote Shooting")):
        large_content = []
        content_list = ['Loading...']
        content_count = 0
        print "Remote Shooting Mode"
        set_camera_function(camera_function)
        time.sleep(4)
        current_function = camera_function
        #LVthread = LiveviewThread()
        LVthread.start()
    else:
        print "NO CHANGE"


@app.route('/_data', methods=['GET', 'POST'])
def data_cb():
    mode = get_exposure_mode()
    avail_aperture = get_avail_aperture()
    avail_shutter = get_avail_shutter()
    avail_iso = get_avail_iso()
    
    my_msg = ''
    if (await_take_pic() == saving_URL):
        my_msg = 'Picture was taken through the WEB PAGE.'
    else:
	    my_msg = 'Picture was taken MANUALLY'
    return jsonify(my_msg=my_msg, waiting=await_take_pic(), mode=mode, aperture=avail_aperture[0], shutter=avail_shutter[0], iso=avail_iso[0], avail_aperture=avail_aperture[1], avail_shutter=avail_shutter[1], avail_iso=avail_iso[1])

@app.route('/contents', methods=['GET', 'POST'])
def contents_cb():
    return jsonify(content_list=content_list, content_count=content_count, large_content=large_content)

# run
#server = wsgi.WSGIServer(('192.168.122.250', 5000), app)
try:
    server = wsgi.WSGIServer(('localhost', 5000), app)
    server.serve_forever()
except:
    exit(0)
