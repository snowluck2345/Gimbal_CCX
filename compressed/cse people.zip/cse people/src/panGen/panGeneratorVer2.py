#!/usr/bin/env python

from const import *
from functions import *
#from tlm_mgr import *

import serial
import time
import msvcrt

'''
def move (yaw,pitch):
    s.write('$1,%s,%snn'%(yaw,pitch))

s = serial.Serial('COM21',baudrate = 57600)
'''

'''
Created on Spring Semester, 2015

@author: Jorge Pacheco
'''

'''
Read values from a file
Values of sensor sizes (horizontal/vertical) and focal length are in mm
Values of horizontal and vertical overlap are in the scale 1-100 %
Example:
22.4
18.8
35.0
30
30
'''
try:
    f = open("Parameters.txt",'r')
    xSensorSize = float(f.readline())
    ySensorSize = float(f.readline())
    focalLength = float(f.readline())
    hOverlap = int(f.readline())
    vOverlap = int(f.readline())
    f.close()
except "IOError":
    SystemExit

#xSensorSize = 22.2
#ySensorSize = 14.8
#focalLength = 35.0

'get values for Horizontal Field of View and Vertical Field of View'
#HFOV = fov(focalLength, xSensorSize)
#VFOV = fov(focalLength, ySensorSize)

HFOV = 33.0
VFOV = 22.3

print HFOV
print VFOV

'specify amount of overlap desired, in scale 1-100%'
#hOverlap = 30
#vOverlap = 30

'calculate the amount of overlap desired for vertical and horizontal stitching'


hOverlapAmount = (HFOV*(hOverlap/100.0))
vOverlapAmount = (VFOV*(vOverlap/100.0))

yDelta = 0.0
pDelta =  0.0

coordinateList = []
coordinateList2 = []

'integers used to calculate offset for center of picture based on overlaps'
n = 0
m = 0
'Simple way to calculate orientations based on overlaps'

'Open file objects to write to'
f = open("CoordinateList.txt",'w')
g = open("StepList.txt",'w')
'Manually add highest point in coordinate space'
coordinateList.append((0,0))
coordinateList2.append((0,0))
f.write(printCoordinate(coordinateList2[0]))
g.write(printCoordinate(coordinateList[0]))
while (pDelta < const.ONEEIGHTY):
    pDelta = (n*(VFOV - vOverlapAmount) + (VFOV/2.0))
    if(pDelta < const.ONEEIGHTY):
        while(yDelta < const.THREESIXTY):
            'Generate Step values for gimbal'
            dummyX = (yDelta*200*8)/360.0
            dummyY = (pDelta*200*8)/360.0
            'Generate 2 separate list for convenience, one in degrees and the other in steps'
            coordinateList2.append((yDelta,pDelta))
            coordinateList.append((dummyX,dummyY))
            'create pair objects with respective step and coordinate values'
            pairStep = (dummyX,dummyY)
            pairCoordinate = (yDelta,pDelta)
            'add pair values to the lists'
            f.write(printCoordinate(pairCoordinate))
            g.write(printCoordinate(pairStep))
            'redefine new pitch value'
            yDelta = (m*(HFOV - hOverlapAmount) + HFOV/2.0)
            m+=1
        yDelta = 0.0
        m = 0
        n+=1

'Close file objects'
f.close()
g.close()
listSize = len(coordinateList)

'''
for w in range (0,listSize):
    #print(printCoordinate(coordinateList[w]) + '.....' + printCoordinate(coordinateList2[w]))
    print(printCoordinate(coordinateList2[w]))
'''    
    
'times needed in order to provide smooth transitions from point to point'  
settlingTime = 2000/1000
exposureTime = 500/1000
bufferTime = 200/1000


for w in range (0,listSize):
    time.sleep(1)
    print( str(coordinateList2[w][0]) + ',' +  str(coordinateList2[w][1]) )
    print(format(coordinateList[w][0]) + ',' +  format(coordinateList[w][1])  + '\n')
    
    'Write value to serial port'
    #move(format(coordinateList[w][0]), format(coordinateList[w][1]))
    time.sleep(1)
 



'''
print('$' + '0' + '00000' + '00000'  + '\n')
'print values of List of Coordinates using exposure, buffering, and settling times'
for w in range (0,listSize):
    #print('$' + '0' + '00000' + '00000'  + '\n')
    print( '$' + '0' + stringGenerator(0, coordinateList[w]) + '\n')
    time.sleep(settlingTime)
    print( '$' + '1' + stringGenerator(0, coordinateList[w]) + '\n')
    time.sleep(exposureTime)
    time.sleep(bufferTime)
'''