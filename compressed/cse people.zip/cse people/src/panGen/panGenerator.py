#!/usr/bin/env python

'''
Created on May 1, 2015

@author: Jorge
'''

from const import *
from functions import *

#import serial
import time
#import msvcrt

'Values of sensor sizes and focal length are in mm'
xSensorSize = 36.0
ySensorSize = 24.0
focalLength = 50.0

'get values for Horizontal Field of View and Vertical Field of View'
HFOV = fov(focalLength, xSensorSize)
VFOV = fov(focalLength, ySensorSize)

'specify amount of overlap desired, in scale 1-100%'
hOverlap = 30
vOverlap = 30

'calculate the amount of overlap desired for vertical and horizontal stitching'
yDelta = (1.0 - (0.01*hOverlap))*HFOV
pDelta = (1.0 - (0.01*vOverlap))*VFOV
yDelta = round(yDelta,1)
pDelta = round(pDelta,1)

currentPan = 0.0
coordinateList = []

while (currentPan < const.ONEEIGHTY):
    yDelta = yawDelta(currentPan, HFOV, pDelta, hOverlap)
    #yDelta = round(yDelta,1)
    yawInc = 0.0
    while(yawInc < 360.0):
        
        #print(yawInc,currentPan)
        coordinateList.append((yawInc,currentPan))
        yawInc+=yDelta
    currentPan+= pDelta

'''
settlingTime = (float(input("Please enter settling time desired(ms) ",))/1000)
exposureTime = (float(input("Enter exposure time(ms) ",))/1000)
bufferTime = (float(input("Enter buffer time(ms) ",))/1000)
'''
    
'times needed in order to provide smooth transitions from point to point'  
settlingTime = 2000/1000
exposureTime = 500/1000
bufferTime = 200/1000
    
#time.sleep(settlingTime)
#time.sleep(exposureTime)
#time.sleep(bufferTime)

'get list size'
listSize = len(coordinateList)
#print(coordinateList[0][0])

'print values of List of Coordinates using exposure, buffering, and settling times'
for w in range (0,listSize):
    print( '$' + '0' + stringGenerator(0, coordinateList[w]) + '\n')
    time.sleep(settlingTime)
    print( '$' + '1' + stringGenerator(0, coordinateList[w]) + '\n')
    time.sleep(exposureTime)
    time.sleep(bufferTime)
    
    
    
    
    

