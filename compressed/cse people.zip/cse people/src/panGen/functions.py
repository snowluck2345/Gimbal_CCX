#!/usr/bin/env python

'''
Created on May 1, 2015

@author: Jorge
'''

from const import *
from math import atan,ceil, cos

'''function calculates field of view based on sensor size and focal length of camera'''
def fov(focalLength, sensorSize):
    return round(2*const.rad2deg * (atan(0.5*(sensorSize/focalLength))),1)

'''function calculates number of horizontal or vertical pictures to take'''
def intGenerator(boolean, fov, overlap):
    #if boolean is true, function assumes is for pan, else for tilt
    if(boolean):
        dummy = const.THREESIXTY
    else:
        dummy = const.ONEEIGHTY
    
    dummy = ceil(100*(dummy/(fov*overlap)))
    return int(dummy)

''' Function that converts float numbers into strings. 
    Length of string has to be 4 in order to work with gimbal. This function takes the number 
    in degrees and proceeds to do formatting cancatinating zeros, making sure number is formatted to 
    correct length  '''

def printCoordinates(degree):
    first = round(degree[0],1)
    second = round(degree[1],1)
    print first, second

def printCoordinate(degree):
    first = str(round(degree[0],1))
    second = str(round(degree[1],1))
    return first + ',' +  second + '\n'

def format(degree):
    number = degree
    number = int(number*1)
    #number = round(number,1)
    if(number > 10000):
        string = str(number)
    elif(number > 1000):
        string = '0' + str(number)
    elif(number > 100):
        string = '00' + str(number)
    elif(number > 10):
        string = '000' + str(number)
    else:
        string = '0000' + str(number)
        
    return string



def stringGenerator(boolean,degree):
    
    '''Two different functionalities for same process.
    'If boolean value is true, then we can assume not optimal pan generator
    was called from main'''
    
    'if boolean is true, degree is just a float and convert it to string'
    'else, degree is a pair of numbers. Grab each one individually and proceed with same process'
    if(boolean):
        degree = int(degree*10)
        if(degree > 1000):
            return str(degree)
        elif(degree > 100):
            return '0' + str(degree)
        elif(degree > 10):
            return '00' + str(degree)
        else:
            return '000' + str(degree)
    else: 
        first = degree[0]
        second = degree[1]
        first = int(first*10)
        round(first,1)
        if(first > 1000):
            string = str(first)
        elif(first > 100):
            string = '00' + str(first)
        elif(first > 10):
            string = '000' + str(first)
        else:
            string = '0000' + str(first)
        
        second = int(second*10)
        round(second,1)
        if(second > 1000):
            return string + str(second)
        elif(second > 100):
            return string + '00' + str(second)
        elif(second > 10):
            return string + '000' + str(second)
        else:
            return string + '0000' + str(second)

'''
    Function provides optimal functionality for the creation of points in space. yawDelta function will
    determine amount of yaw increment needed for specific location of pan.
'''            
def yawDelta(currentPitch, HFOV, pdelta, hOverlap):
    
    'get relative value of pitch from equator'
    currentPitch = abs(currentPitch-90.0)
    
    'calculate top and bottom of field of view rectangle'
    top = currentPitch + round((0.5*currentPitch),1)
    bottom = currentPitch - round((0.5*currentPitch),1)
    
    'distances from equator'
    eqDistTop = abs(top)
    eqDistBottom = abs(bottom)
    
    HFOV *= (1.0- 0.01*hOverlap)
    
    'if top is closer to equator, use top, else use bottom'
    if(eqDistTop < eqDistBottom):
        dummy = int(10.0*(HFOV/cos(const.deg2rad*top)))
        return round(0.1*dummy,1)
    else:
        dummy = int(10.0*(HFOV/cos(const.deg2rad*bottom)))
        return round(0.1*dummy,1)
    
    
    
    


