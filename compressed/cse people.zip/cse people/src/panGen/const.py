'''
Created on Apr 13, 2015

@author: Jorge
'''

''' Constants used in main or function program '''
class const:
    THREESIXTY = 360.0
    ONEEIGHTY = 180.0
    PI = 3.14159265359
    deg2rad = PI/ONEEIGHTY
    rad2deg = ONEEIGHTY/PI
