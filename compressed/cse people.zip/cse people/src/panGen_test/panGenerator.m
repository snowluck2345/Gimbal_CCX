close all;
xSensorSize = 22.3;   % Horizontal Sensor Size in mm
ySensorSize = 14.9;   % Vertical Sensor Size in mm
focalLength = 35;  % Focal Length in mm
cropFactor = 1.6;

xFOV = 2 * atan2(xSensorSize, 2 * focalLength) * cropFactor;
yFOV = 2 * atan2(ySensorSize, 2 * focalLength) * cropFactor;

data = csvread('../panGen/coord.txt');

figure;
x = zeros(length(data),1);
y = zeros(length(data),1);
z = zeros(length(data),1);

xcount = 1;

for i = 1:1:length(data)
    x(i) = sin(deg2rad(data(i, 1))) * cos(deg2rad(data(i, 2)));
    y(i) = sin(deg2rad(data(i, 1))) * sin(deg2rad(data(i, 2)));
    z(i) = cos(deg2rad(data(i, 1)));
    if abs(z(i)) < 0.2
        xcount = xcount + 1;
    end
end
plot3(x, y, z, '*');
axis square;

figure;


theta = zeros(xcount,1);
rho = zeros(xcount,1);
xcount = 1;

for i = 1:1:length(data)
    if abs(cos(deg2rad(data(i, 2)))) < 0.2
        theta(xcount) = deg2rad(data(i, 1));
        rho(xcount) = 1;
        xcount = xcount + 1;
    end
end
polar(theta, rho, '*');
axis square;