#include <sys/capability.h> // apt-get install libcap-dev if doesn't exist
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/if_ether.h>

#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <netpacket/packet.h>

#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cstring>

#include "tunnel.h"
#include "packet_forger.h"
using namespace std;


// To set capabilities for this program:
//  - sudo apt-get install libcap-dev
//  - make
//  - sudo setcap cap_net_admin,cap_net_raw+ep multicam

/* TODO (program outline)
    - Load config settings that specify parameters for TUN device, cameras, etc.
    - Create TUN device
    - Set the TUN device to have an IP based on config data (e.g. 192.168.200.1)
    - Open a raw socket for each camera's Wi-Fi network
    - poll for data on the combined set of the TUN fd and raw socket fds
    - for each packet received:
        - if the packet came from a camera, modify the IP addresses
          to correspond to a virtual address for the camera and the
          destination to the TUN's IP address, then write it out to TUN.
          
        - if the packet came from our PC, determine which camera the
          message is for based on the IP address, and then rewrite
          the IP addresses so that it looks like it was sent from the 
          correct Wi-Fi to the common camera IP address, and send the
          packet out the correct raw socket.
    - Don't forget to recalculate the IP header checksum!
*/

bool have_capability(cap_value_t which)
{
    cap_t caps;
    caps = cap_get_proc();
    if(caps == NULL)
    {
        return false;   // can't get caps at all!
    }
    
    cap_flag_value_t result = CAP_CLEAR;
    
    if(cap_get_flag(caps, which, CAP_EFFECTIVE, &result) != 0)
    {
        perror("cap_get_flag");
        return false;   // invalid value for "which"?
    }
    
    cap_free(caps);
    return (result == CAP_SET);
}

int make_raw_socket(const string& interface, int* out_sll_ifindex)
{
    //int fd = socket(AF_INET, SOCK_RAW, htons(ETH_P_IP));
    int fd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_IP));
    //int fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    
    if(fd < 0)
    {
        perror("socket");
        throw std::runtime_error("bad socket");
    }
    
    //#if 0
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, interface.c_str(), IFNAMSIZ);
    if((ioctl(fd, SIOCGIFINDEX, &ifr)) < 0)
    {
        perror("make_raw_socket ioctl");
        throw std::runtime_error("could not find interface index (" + interface
            + ")");
    }
    cerr << "interface " << interface << " index is " << ifr.ifr_ifindex << endl;
    
    struct sockaddr_ll sll;
    memset(&sll, 0, sizeof(sll));
    sll.sll_family = AF_PACKET;
    sll.sll_ifindex = ifr.ifr_ifindex;
    sll.sll_protocol = htons(ETH_P_IP);
    
    if(bind(fd, (struct sockaddr*)&sll, sizeof(sll)) < 0)
    {
        perror("bind");
        throw std::runtime_error("failed to bind to interface (" + interface +
            ")");
    }
    
    if(out_sll_ifindex)
        *out_sll_ifindex = sll.sll_ifindex;
    //#endif
    
    
    #if 0
    
    int enable = 1;
    if(setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &enable, sizeof(enable)) < 0)
    {
        perror("setsockopt IP_HDRINCL");
        throw std::runtime_error("failed to request ip headers");
    }
    
    if(setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, interface.c_str(),
        interface.size()) < 0)
    {
        perror("setsockopt SO_BINDTODEVICE");
        throw std::runtime_error("failed to bind to interface (" + interface +
            ")");
    }
    
    #endif
    
    cerr << "raw socket for " << interface << " fd = " << fd << endl;
    return fd;
}    


int main()
{
    if(!have_capability(CAP_NET_ADMIN))
    {
        cerr << "Missing CAP_NET_ADMIN capability\n";
        return EXIT_FAILURE;
    }
    
    if(!have_capability(CAP_NET_RAW))
    {
        cerr << "Missing CAP_NET_RAW capability\n";
        return EXIT_FAILURE;
    }
    
    Tunnel tunnel;
    if(!tunnel.create())
    {
        cerr << "Failed to create tunnel!\n";
        return EXIT_FAILURE;
    }
    
    cerr << "Tunnel created was named: " << tunnel.get_device_name() << '\n';
    
    tunnel.set_ip("192.168.200.1");
    tunnel.set_netmask("255.255.255.0");
    tunnel.up();
    
    #if 0
    while(true)
    {
        unsigned char buffer[BUFSIZ];
        memset(buffer, 0, sizeof(buffer));
        int status = read(tunnel.get_fd(), buffer, BUFSIZ);
        
        const struct iphdr* packet = (const struct iphdr*)buffer;
        
        if(status > 0)
        {
            uint16_t sum = ipv4_compute_checksum(packet);
        
            fprintf(stderr, "\nFROM: %s", inet_ntoa(*(struct in_addr*)&packet->saddr));
            fprintf(stderr, "\nTO:   %s", inet_ntoa(*(struct in_addr*)&packet->daddr));
            fprintf(stderr, "\nSUM:  %s (packet: %u -- computed: %u)\n", (sum == packet->check)?"OK" : "ERROR", 
                packet->check, sum);
            for(int i = 0; i < status; i++)
            {
                fprintf(stderr, "%02X  ", (unsigned int)buffer[i]);
                if(i > 0 && i % 20 == 0)
                    fprintf(stderr, "\n");
            }
            
            fprintf(stderr, "\n");
        }
    }
    #endif
    
    int wlan1_sll_ifindex = 0, wlan2_sll_ifindex = 2;
    
    int tunnel_socket = tunnel.get_fd();
    int dev_null = open("/dev/null", O_WRONLY);
    int wlan1_socket = make_raw_socket("wlan1", &wlan1_sll_ifindex);
    int wlan2_socket = make_raw_socket("wlan2", &wlan2_sll_ifindex);
    
    PacketForger forger;
    
    // tun0 -> wlan1
    if(1)
    {
        Rule rule;
        rule.set_read_type(READTYPE_READ);
        rule.set_source_socket(tunnel_socket);
        rule.set_destination_socket(wlan1_socket);
        
        rule.set_match_source_ip("192.168.200.1");
        rule.set_match_destination_ip("192.168.200.2");
        
        rule.set_forge_source_ip("192.168.122.199");
        rule.set_forge_destination_ip("192.168.122.1");
        
        rule.send_ethernet_header = true;
        string dst_mac = "9a:f1:70:0d:ac:f2";
        string src_mac = "14:cc:20:1d:52:e8";
        rule.set_ethernet_header(dst_mac, src_mac);
     
        rule.sll_ifindex = wlan1_sll_ifindex;
        
        forger.add_rule(rule);
    }
    
    // wlan1 -> tun0
    if(1)
    {
        Rule rule;
        
        rule.set_read_type(READTYPE_RECVFROM);
        rule.set_source_socket(wlan1_socket);
        rule.set_destination_socket(tunnel_socket);
        
        rule.set_match_source_ip("192.168.122.1");
        rule.set_match_any_destination();
        
        rule.set_forge_source_ip("192.168.200.2");
        rule.set_forge_destination_ip("192.168.200.1");
        
        rule.recv_ethernet_header = true;
        rule.send_ethernet_header = false;
        
        forger.add_rule(rule);
    }
    
    // tun0 -> wlan2
    if(1)
    {
        Rule rule;
        rule.set_read_type(READTYPE_READ);
        rule.set_source_socket(tunnel_socket);
        rule.set_destination_socket(wlan1_socket);
        
        rule.set_match_source_ip("192.168.200.1");
        rule.set_match_destination_ip("192.168.200.3");
        
        rule.set_forge_source_ip("192.168.122.215");
        rule.set_forge_destination_ip("192.168.122.1");
        
        rule.send_ethernet_header = true;
        string dst_mac = "9a:f1:70:98:09:f6";
        string src_mac = "14:cc:20:1d:6d:46";
        rule.set_ethernet_header(dst_mac, src_mac);
        
        rule.sll_ifindex = wlan2_sll_ifindex;
        
        forger.add_rule(rule);
    }
    
    // wlan2 -> tun0
    if(1)
    {
        Rule rule;
        
        rule.set_read_type(READTYPE_RECVFROM);
        rule.set_source_socket(wlan2_socket);
        rule.set_destination_socket(tunnel_socket);
        
        rule.set_match_source_ip("192.168.122.1");
        rule.set_match_any_destination();
        
        rule.set_forge_source_ip("192.168.200.3");
        rule.set_forge_destination_ip("192.168.200.1");
        
        rule.recv_ethernet_header = true;
        rule.send_ethernet_header = false;
        
        forger.add_rule(rule);
    
    }
    
    forger.run();
    
    return 0;
}

