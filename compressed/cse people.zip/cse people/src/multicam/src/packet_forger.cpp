#include "packet_forger.h"

#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/poll.h>
#include <unistd.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netpacket/packet.h>

#include <cstddef>
#include <vector>
#include <set>
#include <iostream>
#include <cstring>
using namespace std;

// computes the network byte order checksum of an ip packet header
// suitable for direct comparison or insertion into the header
uint16_t ipv4_compute_checksum(const struct iphdr* hdr)
{
    uint8_t* bytes = (uint8_t*)hdr;
    uint32_t sum = 0;
    
    for(int i = 0; i < (int)sizeof(*hdr); i += 2)
    {
        // skip the checksum field in this calculation
        if(i == offsetof(struct iphdr, check))
            continue;
    
        // read in bytes AB in big endian from packet
        uint8_t A = bytes[i];
        uint8_t B = bytes[i+1];
        
        uint16_t AB = (A << 8) | B;
        
        sum += AB;
    }
    
    uint16_t carry = sum >> 16;
    sum &= 0xFFFF;
    sum += carry;
    //sum &= 0xFFFF;
    sum  = ~sum;
    sum &= 0xFFFF;
    
    uint16_t result = sum;
    return htons(result);
}

string ipv4_packet_src_ip(const struct iphdr* hdr)
{
    string result = inet_ntoa(*(struct in_addr*)&hdr->saddr);
    return result;
}

string ipv4_packet_dst_ip(const struct iphdr* hdr)
{
    string result = inet_ntoa(*(struct in_addr*)&hdr->daddr);
    return result;
}

uint16_t udp_compute_checksum(const struct iphdr* ip_header)
{
    return 0; // FIXME
}

void rewrite_udp_checksum(struct iphdr* ip_header)
{

}

// references:
// http://locklessinc.com/articles/tcp_checksum/
// http://www.tcpipguide.com/free/t_TCPChecksumCalculationandtheTCPPseudoHeader-2.htm
uint16_t tcp_compute_checksum(const struct iphdr* ip_header)
{
    uint8_t* bytes = (uint8_t*)ip_header;
    tcphdr* tcp_header = (tcphdr*)(bytes + ip_header->ihl*4);
    
    fprintf(stderr, "Computing checksum for TCP packet to port %d from port %d\n", 
        ntohs(tcp_header->th_dport), ntohs(tcp_header->th_sport));
    
    uint16_t ip_length = ntohs(ip_header->tot_len);
    uint16_t tcp_length = ip_length - (ip_header->ihl*4);
    
    uint32_t sum = 0;
    
    // compute sum for IP pseudo header
    unsigned char pseudo[12];
    memcpy(&pseudo[0], &ip_header->saddr, 4);
    memcpy(&pseudo[4], &ip_header->daddr, 4);
    pseudo[8] = 0; // reserved 0
    pseudo[9] = 6; // protocol is obviously TCP
    pseudo[10] = tcp_length >> 8;
    pseudo[11] = 0xFF & tcp_length;
    
    for(int i = 0; i < 12; i+=2)
    {
        uint8_t A = pseudo[i];
        uint8_t B = pseudo[i+1];
        uint16_t AB = (A << 8) | B;
        
        sum += AB;
    }
    
    //fprintf(stderr, "TCP Length: %d\n", tcp_length);
    
    // compute checksum over actual TCP header and data
    int tcp_checksum_offset = (ip_header->ihl*4) + offsetof(struct tcphdr, th_sum);
    //fprintf(stderr, "PARTIAL SUM: %d\n", sum);
    
    // note the tricky ending condition to handle odd packets...
    // if we have an even length packet, removing last byte doesn't affect
    // loop run length since we increment by two; if it is an odd length,
    // we skip the last byte in this loop and handle it with the conditional
    // below.
    for(int i = (ip_header->ihl*4); i < ip_length-1; i+=2)
    {
        if(i == tcp_checksum_offset)
        {
            //fprintf(stderr, "old checksum in packet is: %d\n",
            //    ntohs(*(uint16_t*)&bytes[i]));
            continue;
        }
    
        uint8_t A = bytes[i];
        uint8_t B = bytes[i+1];
        uint16_t AB = (A << 8) | B;
        
        sum += AB;
    }
    
    if(ip_length & 1)
    {
        uint8_t A = bytes[ip_length-1];
        sum += A << 8;
    }
    
    // add overflow
    while(sum >> 16)
    {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    
    sum = ~sum;
    uint16_t result = sum & 0xFFFF;
    return htons(result);
}

void rewrite_tcp_checksum(struct iphdr* ip_header)
{
    uint16_t checksum = tcp_compute_checksum(ip_header);
    struct tcphdr* tcp_header = (struct tcphdr*)(ip_header+1);
    tcp_header->th_sum = checksum;
}

void hexdump_packet(unsigned char* buffer, int bytes)
{   
    for(int i = 0; i < bytes; i++)
    {
        fprintf(stderr, "%02X  ", buffer[i]);
        if(i > 0 && i % 20 == 0)
            fprintf(stderr, "\n");
    }
    
    fprintf(stderr, "\n");
}

Rule::Rule()
{
    src_fd = -1;
    dst_fd = -1;
    read_type = READTYPE_RECVFROM;
    nbo_match_src_ip = 0;
    nbo_match_dst_ip = 0;
    nbo_forge_src_ip = 0;
    nbo_forge_dst_ip = 0;
    
    any_source = false;
    any_destination = false;
    
    recv_ethernet_header = false;
    send_ethernet_header = false;
    memset(&ethernet_header, 0, sizeof(ethernet_header));
}

void Rule::set_ethernet_header(std::string dst_mac, std::string src_mac)
{
    memcpy(ethernet_header.ether_dhost, ether_aton(dst_mac.c_str()),
        sizeof(ethernet_header.ether_dhost));
    memcpy(ethernet_header.ether_shost, ether_aton(src_mac.c_str()),
        sizeof(ethernet_header.ether_shost));
    ethernet_header.ether_type = htons(ETH_P_IP);
}

void Rule::translate_ip(uint32_t& into, const std::string& ip)
{
    struct in_addr ia;
    
    if(inet_aton(ip.c_str(), &ia) == 0)
    {
        throw std::invalid_argument("bad ip address");
    }
    
    into = ia.s_addr;
}

void Rule::set_match_source_ip(const std::string& ip)
{
    translate_ip(nbo_match_src_ip, ip);
    any_source = false;
}

void Rule::set_match_destination_ip(const std::string& ip)
{
    translate_ip(nbo_match_dst_ip, ip);
    any_source = false;
}

void Rule::set_forge_source_ip(const std::string& ip)
{
    translate_ip(nbo_forge_src_ip, ip);
}

void Rule::set_forge_destination_ip(const std::string& ip)
{
    translate_ip(nbo_forge_dst_ip, ip);
}

bool Rule::match_packet(const struct iphdr* ip_packet)
{
    bool match_src = any_source || (ip_packet->saddr == nbo_match_src_ip);
    bool match_dst = any_destination || (ip_packet->daddr == nbo_match_dst_ip);

    return (match_src && match_dst);    
}
    
void Rule::translate_packet(struct iphdr* ip_packet)
{
    cerr << "translating packet" << endl;
    ip_packet->saddr = nbo_forge_src_ip;
    ip_packet->daddr = nbo_forge_dst_ip;
    ip_packet->check = ipv4_compute_checksum(ip_packet);
    
    switch(ip_packet->protocol)
    {
        case 0x11: // UDP
            fprintf(stderr, "FIXME: Update UDP Checksums\n");
            break;
        
        case 0x06: // TCP
            rewrite_tcp_checksum(ip_packet);
            break;
        
        default:
            break;
    }
    
    cerr << "FORGED FROM: " << ipv4_packet_src_ip(ip_packet) << '\n';
    cerr << "FORGED TO:   " << ipv4_packet_dst_ip(ip_packet) << endl;
}

// ----------------------------------------------------------------------------

void PacketForger::add_rule(Rule rule)
{
    int key = rule.src_fd;
    std::vector<Rule>& list = m_rule_table[key];
    list.push_back(rule);
    
    m_fd_set.insert(rule.src_fd);
    
    if(m_read_type.find(key) != m_read_type.end())
    {
        if(m_read_type[key] != rule.read_type)
        {
            throw std::logic_error("Cannot add rule with conflicting read type");
        }
    }
    else
    {
        m_read_type[key] = rule.read_type;
    }
    
    if(m_recv_ethernet_header.find(rule.src_fd) != m_recv_ethernet_header.end())
    {
        if(m_recv_ethernet_header[rule.src_fd] != rule.recv_ethernet_header)
        {
            throw std::logic_error("Cannot add rule with conflicting recv ethernet header handling");
        }
        
    }
    else
    {
        m_recv_ethernet_header[rule.src_fd] = rule.recv_ethernet_header;
    }
}

bool validate_checksums(struct iphdr* packet)
{
    uint16_t ipv4_expect_checksum = ipv4_compute_checksum(packet);

    if(ipv4_expect_checksum != packet->check)
    {
        fprintf(stderr, "BAD IPv4 Checksum: Got 0x%04X, expected 0x%04X\n",
            packet->check, ipv4_expect_checksum);
            
        return false;
    }
    
    switch(packet->protocol)
    {
        case 0x11: // UDP
            fprintf(stderr, "FIXME: UDP Checksums\n");
            return true;
        
        case 0x06: // TCP
        {
            struct tcphdr* tcp_header = (struct tcphdr*)(packet+1);
            uint16_t got_checksum = ntohs(tcp_header->th_sum);
            uint16_t expected_checksum = ntohs(tcp_compute_checksum(packet));
            
            if(got_checksum != expected_checksum)
            {
                fprintf(stderr, "BAD TCP Checksum: Got 0x%04X, expected 0x%04X\n",
                    got_checksum, expected_checksum);
                return false; // drop packet
            }
            
            return true; // packet ok
        }
        
        default:
            return true;
    }
}

void PacketForger::run()
{
    /* --- TODO ---
        build poll set
        poll on set in a loop
        
        for each socket recv'ing data in the loop:
            look up rules in m_rule_table
            for each rule:
                if rule.handle_packet(packet):
                    write to destination fd
                    break
    */
    
    vector<struct pollfd> poll_list;
    vector<char> buffer(2 * 0xFFFF); // only need 65535 bytes; 2x just in case
    
    for(int fd : m_fd_set)
    {
        struct pollfd pfd;
        memset(&pfd, 0, sizeof(pfd));
        pfd.fd = fd;
        pfd.events = POLLIN;
        
        poll_list.push_back(pfd);
    }
    
    while(true)
    {
        int poll_status = poll(&poll_list[0], poll_list.size(), 1000);
        
        if(poll_status == -1)
        {
            perror("poll");
            continue;
        }
        else if(poll_status == 0)
        {
            continue;   // time out / interrupted
        }
        
        for(size_t i = 0; i < poll_list.size(); i++)
        {
            struct pollfd& pfd = poll_list[i];
            if(pfd.revents & POLLIN)
            {
                cerr << endl;
                int recv_count = 0;
                
                switch(m_read_type[pfd.fd])
                {
                    case READTYPE_READ:
                        recv_count = read(pfd.fd, (void*)&buffer[0], buffer.size());
                        break;
                        
                    case READTYPE_RECVFROM:
                        recv_count = read(pfd.fd, (void*)&buffer[0], buffer.size());
//                        recv_count = recvfrom(pfd.fd, (void*)&buffer[0],
//                            buffer.size(), 0, NULL, NULL);
                        break;
                        
                    default:
                        throw std::logic_error("Invalid ReadType");
                }
                
                if(recv_count < 0)
                {
                    perror("PacketForger read/recvfrom");
                    continue;
                }
                
                
                struct iphdr* packet = (struct iphdr*)&buffer[0];
                size_t expect_recv_at_least = sizeof(struct iphdr);
                size_t expect_packet_claim  = 0;
                
                if(m_recv_ethernet_header[pfd.fd])
                {
                    expect_recv_at_least += 14; // expect ethernet header too
                    
                    // add 14 bytes to the length the packet claims it has
                    // in order to account for the ethernet header
                    expect_packet_claim += 14;
                    
                    // update pointer to skip ethernet header
                    char* packet_octets = (char*)packet;
                    packet_octets += 14; // skip ethernet header
                    packet = (struct iphdr*)packet_octets;
                    
                }
                
                // sanity check this to make sure we at least got an IP header
                // If not, then don't try to read the packet length from the
                // non-existant header!
                if((size_t)recv_count < expect_recv_at_least)
                {
                    cerr << "Packet too short!" << endl;
                    continue;
                }
                
                cerr << "FROM: " << ipv4_packet_src_ip(packet) << '\n';
                cerr << "TO:   " << ipv4_packet_dst_ip(packet) << endl;
                
                // add the length the IP header claims its data is to
                // the amount we were expecting (either 0 for IP only,
                // or 14 if we're expecting an ethernet header)
                expect_packet_claim += ntohs(packet->tot_len);
                
                if((size_t)recv_count != expect_packet_claim)
                {
                    fprintf(stderr, "Wrong number of bytes: read %d, packet claims %d\n",
                        recv_count, packet->tot_len);
                    continue; // drop packet
                }
                
                int send_bytes = recv_count - ((char*)packet-(char*)&buffer[0]);
                
                if(!validate_checksums(packet))
                {
                    continue; // drop packet
                }
                
                bool handled = false;
                
                vector<Rule>& rule_list = m_rule_table[pfd.fd];
                for(Rule& rule : rule_list)
                {
                    if(rule.handle_packet(packet))
                    {
                        int write_count = -1;
                        
//                        if(m_read_type[pfd.fd] != READTYPE_RECVFROM)
//                        {
//                            struct sockaddr_in sin;
//                            memset(&sin, 0, sizeof(sin));
//                            sin.sin_family = AF_INET;
//                            sin.sin_addr.s_addr = packet->daddr;
//                            
//                            write_count = sendto(rule.dst_fd,
//                                (void*)&buffer[0], recv_count, 0,
//                                (const struct sockaddr*)&sin,
//                                sizeof(sin));
//                        }
//                        else

                        if(rule.send_ethernet_header)
                        {
                            struct iovec iov[2];
                            
                            iov[0].iov_base = &rule.ethernet_header;
                            iov[0].iov_len  = sizeof(rule.ethernet_header);
                            
                            iov[1].iov_base = packet;
                            iov[1].iov_len  = send_bytes;
                            
                            struct sockaddr_ll sll;
                            memset(&sll, 0, sizeof(sll));
                            sll.sll_family = AF_PACKET;
                            sll.sll_ifindex = rule.sll_ifindex;
                            sll.sll_halen = ETHER_ADDR_LEN;
                            sll.sll_protocol = ETH_P_IP;
                            memcpy(&sll.sll_addr, 
                                rule.ethernet_header.ether_dhost,
                                ETHER_ADDR_LEN);
                            
                            struct msghdr msg;
                            memset(&msg, 0, sizeof(msg));
                            msg.msg_name = &sll;
                            msg.msg_namelen = sizeof(sll);
                            msg.msg_iov = iov;
                            msg.msg_iovlen = 2;
                            
                            write_count = sendmsg(rule.dst_fd, &msg, 0);
                        }
                        else
                        {
                            write_count = write(rule.dst_fd, 
                                (void*)packet, send_bytes);
                        }
                        
                        if(write_count < 0)
                        {
                            cerr << "ERRNO: " << errno << endl;
                            perror("write");
                        }
                        
                        handled = true;
                        break;
                    }
                }
                
                if(!handled)
                    hexdump_packet((unsigned char*)&buffer[0], recv_count);
            }
        }
    }
}

