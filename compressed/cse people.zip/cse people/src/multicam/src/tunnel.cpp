#include "tunnel.h"

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <linux/if_tun.h>
#include <unistd.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#include <cstdio>
#include <cstring>
#include <stdexcept>

Tunnel::Tunnel()
{
    m_created = false;
    m_device_name = "";
    m_fd = -1;
}

// see: https://www.kernel.org/doc/Documentation/networking/tuntap.txt
bool Tunnel::create(std::string request_name_pattern)
{
    struct ifreq ifr;
    
    if(m_created)
        return false;   // device has already been created!
    
    if((m_fd = open("/dev/net/tun", O_RDWR)) < 0)
    {
        perror("open /dev/net/tun");
        return false;
    }
    
    memset(&ifr, 0, sizeof(ifr));
    ifr.ifr_flags = IFF_TUN | IFF_NO_PI;
    
    if(request_name_pattern.size())
    {
        strncpy(ifr.ifr_name, request_name_pattern.c_str(), IFNAMSIZ);
    }
    
    if(ioctl(m_fd, TUNSETIFF, (void*)&ifr) < 0)
    {
        perror("ioctl TUNSETIFF");
        close(m_fd);
        m_fd = -1;
        return false;
    }
    
    m_device_name = ifr.ifr_name;
    m_created = true;
    
    return true;
}

int Tunnel::get_fd()
{
    if(!m_created)
        throw std::logic_error("tunnel not created");
    
    return m_fd;
}

std::string Tunnel::get_device_name()
{
    if(!m_created)
        throw std::logic_error("tunnel not created");
    
    return m_device_name;
}

void Tunnel::up()
{
    int fd;
    struct ifreq ifr;
    
    if(!m_created)
        throw std::logic_error("tunnel not created");
    
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd < 0)
    {
        perror("Tunnel::up socket");
        return;
    }
    
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, m_device_name.c_str(), IFNAMSIZ);
    ifr.ifr_flags = IFF_UP | IFF_BROADCAST | IFF_RUNNING | IFF_MULTICAST;
    
    if(ioctl(fd, SIOCSIFFLAGS, &ifr) < 0)
    {
        perror("Tunnel::up ioctl");
    }
    
    close(fd);
}

void Tunnel::down()
{
    int fd;
    struct ifreq ifr;
    
    if(!m_created)
        throw std::logic_error("tunnel not created");
    
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd < 0)
    {
        perror("Tunnel::down socket");
        return;
    }
    
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, m_device_name.c_str(), IFNAMSIZ);
    ifr.ifr_flags = 0;
    
    if(ioctl(fd, SIOCSIFFLAGS, &ifr) < 0)
    {
        perror("Tunnel::down ioctl");
    }
    
    close(fd);
}


void Tunnel::set_ip(const std::string& address)
{
    int fd;
    struct ifreq ifr;
    
    // sockaddr_in is equivalent to sockaddr with different named components
    // (in particular, sai.sin_familiy == ifr.ifr_addr.sa_family and
    // ifr.ifr_addr.data is a char[14] block corresponding to sai.sin_addr, etc.
    // They probably both exist because C uses struct reinterpretation to
    // work around lack of language support for inheritance...
    // Creating this reference here so I can access the parts by name.
    struct sockaddr_in& sai = *(sockaddr_in*)&ifr.ifr_addr;
    
    if(!m_created)
        throw std::logic_error("tunnel not created");
    
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd < 0)
    {
        perror("Tunnel::set_ip socket");
        return;
    }
    
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, m_device_name.c_str(), IFNAMSIZ);
    
    sai.sin_family = AF_INET;
    if(inet_aton(address.c_str(), &sai.sin_addr) == 0)
    {
        close(fd);
        throw std::invalid_argument("bad ip address");
    }
    
    if(ioctl(fd, SIOCSIFADDR, (void*)&ifr) < 0)
    {
        perror("Tunnel::set_ip ioctl");
    }
    
    close(fd);
}

void Tunnel::set_netmask(const std::string& netmask)
{
    int fd;
    struct ifreq ifr;
    
    // sockaddr_in is equivalent to sockaddr with different named components
    // (in particular, sai.sin_familiy == ifr.ifr_addr.sa_family and
    // ifr.ifr_addr.data is a char[14] block corresponding to sai.sin_addr, etc.
    // They probably both exist because C uses struct reinterpretation to
    // work around lack of language support for inheritance...
    // Creating this reference here so I can access the parts by name.
    struct sockaddr_in& sai = *(sockaddr_in*)&ifr.ifr_addr;
    
    if(!m_created)
        throw std::logic_error("tunnel not created");
    
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd < 0)
    {
        perror("Tunnel::set_netmask socket");
        return;
    }
    
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, m_device_name.c_str(), IFNAMSIZ);
    
    sai.sin_family = AF_INET;
    if(inet_aton(netmask.c_str(), &sai.sin_addr) == 0)
    {
        close(fd);
        throw std::invalid_argument("bad netmask");
    }
    
    if(ioctl(fd, SIOCSIFNETMASK, (void*)&ifr) < 0)
    {
        perror("Tunnel::set_netmask ioctl");
    }
    
    close(fd);
}

