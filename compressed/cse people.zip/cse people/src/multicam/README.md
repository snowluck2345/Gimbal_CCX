Multicam
========

Multicam packet forger creates a tunnel device and uses it to transfer
IP packets between two wireless NICs with conflicting network addresses.

It is currently at the proof of concept stage. Much work remains to be done
in limiting which packets need to be translated (just to/from TCP 8080?),
automatically determining which NIC is which, determining what IPs to use
programmatically, etc.


Compilation
-----------

    sudo apt-get install libcap-dev
    make
    sudo setcap cap_net_admin,cap_net_raw+ep multicam

This program needs to create network interfaces and uses raw sockets.
In order to avoid having to run the program as root, setcap can be used
as shown above to grant the executable the required permissions.


