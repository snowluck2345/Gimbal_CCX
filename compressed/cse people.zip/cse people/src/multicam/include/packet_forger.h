#pragma once

#include <string>
#include <cstdint>
#include <vector>
#include <map>
#include <set>

#include <netinet/ip.h>
#include <net/ethernet.h>   // for ethernet frame struct
#include <netinet/ether.h>  // for ethernet address ASCII converters


// computes the network byte order checksum of an ip packet header
// suitable for direct comparison or insertion into the header
uint16_t ipv4_compute_checksum(const struct iphdr* hdr);

std::string ipv4_packet_src_ip(const struct iphdr* hdr);
std::string ipv4_packet_dst_ip(const struct iphdr* hdr);

enum ReadType
{
    READTYPE_READ,      // read packets from fd with read(...)
    READTYPE_RECVFROM   // read packets from fd with recvfrom(...)
};

struct Rule
{
    friend class PacketForger;
    
    int src_fd;
    int dst_fd;
    
    ReadType read_type;
    
    // IPs in Network Byte Order
    uint32_t nbo_match_src_ip;
    uint32_t nbo_match_dst_ip;
    uint32_t nbo_forge_src_ip;
    uint32_t nbo_forge_dst_ip;
    
    bool any_source;
    bool any_destination;
    
    bool recv_ethernet_header;
    bool send_ethernet_header;
    struct ether_header ethernet_header; // used if send_ethernet_header set
    
    int sll_ifindex;
    
    void translate_ip(uint32_t& into, const std::string& ip);
    
  public:
    Rule();
    
    void set_ethernet_header(std::string dst_mac, std::string src_mac);
    
    void set_read_type(ReadType type)
    {
        read_type = type;
    }
    
    void set_source_socket(int fd)
    {
        src_fd = fd;
    }
    
    void set_destination_socket(int fd)
    {
        dst_fd = fd;
    }
    
    void set_match_any_source()
    {
        any_source = true;
    }
    
    void set_match_any_destination()
    {
        any_destination = true;
    }
    
    void set_match_source_ip(const std::string& ip);
    void set_match_destination_ip(const std::string& ip);
    
    void set_forge_source_ip(const std::string& ip);
    void set_forge_destination_ip(const std::string& ip);
    
    // returns true if the source and destination in packet are the match IPs
    bool match_packet(const struct iphdr* ip_packet);
    
    // writes the forge IPs into the IP header and fixes the checksum
    void translate_packet(struct iphdr* ip_packet);
    
    
    bool handle_packet(struct iphdr* ip_packet)
    {
        bool rule_applies = match_packet(ip_packet);
        
        if(rule_applies)
            translate_packet(ip_packet);
        
        return rule_applies;
    }
};

class PacketForger
{
    // maps src_fd to list of rules that should be applied to packets on that fd
    std::map<int, std::vector<Rule> > m_rule_table;
    std::map<int, ReadType> m_read_type;
    std::map<int, bool> m_recv_ethernet_header;
    std::set<int> m_fd_set;
    
  public:
    void add_rule(Rule rule);
    void run();
};

