#pragma once

#include <string>

class Tunnel
{
    bool m_created;
    
    // these are only valid if m_created is true
    std::string m_device_name;
    int         m_fd;
    
  public:
    Tunnel();
    
    bool        create(std::string request_name_pattern = "");
    int         get_fd();
    std::string get_device_name();
    void        up();
    void        down();
    void        set_ip(const std::string& address);
    void        set_netmask(const std::string& netmask); // e.g. 255.255.255.0
};

