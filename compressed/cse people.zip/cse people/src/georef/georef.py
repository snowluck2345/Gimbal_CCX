#!/usr/bin/env python
georef_result = namedtuple("georef_result", "lat lon alt")

