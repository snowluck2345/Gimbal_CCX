/**
 * This library provides functions for coordinate geoposition referencing based
 * on location and angles.  All values are stored as double precision floating
 * point numbers.  All references are NED, rotations using Tait-Bryan angle
 * composition x-y-z or x-y'-z''.
 *
 * @author NATHAN T. HUI
 * @email nthui@eng.ucsd.edu
 */

//////////////
// Includes //
//////////////
#include <stdlib.h>
#include <math.h>
#include "libgeoref.h"

///////////////
// Constants //
///////////////
double EARTH_RADIUS = 6378137;	// meters


/////////////////////////
// Function Prototypes //
/////////////////////////
double eavg_vectors(double *, size_t);
double *ediv_vectors(double *, double *, size_t);
double dot_vectors(double *, double *, size_t);
double *addx_vectors(double, double *, double *, size_t);
double *add_vectors(double *, double *, size_t);
double **eulerToDCM(double *);

//////////////////////////
// Function Definitions //
//////////////////////////
/**
 * Calculates and returns the element-wise average of the supplied vector.  In
 * other words, this function takes the set of elements that comprise the vector
 * and calculates the average of that set.  This function does not modify a.
 *
 * @param  a    Vector
 * @param  size Size of vector
 * @return      Element-wise average of supplied vector
 */
double eavg_vectors(double *a, size_t size) {
	double retVal = 0;
	for (size_t i = 0; i < size; i++) {
		retVal += a[i];
	}
	return retVal / size;
}
/**
 * Calculates and returns the element-wise quotient of the supplied vectors,
 * i.e. a / b.  This function will not modify the vectors at a or b.
 *
 * @param  a    First Vector (numerator)
 * @param  b    Second Vector (denominator)
 * @param  size Size of vectors
 * @return      Element-wise quotient of a and b
 */
double *ediv_vectors(double *a, double *b, size_t size) {
	double *retval = malloc(sizeof(double) * size);
	for (size_t i = 0; i < size; i++) {
		retval[i] = a[i] / b[i];
	}
	return retval;
}
/**
 * Calculatees and returns the dot product of the supplied vectors, i.e. a^T *
 * b.  This function will not modify the vectors at a or b.
 *
 * @param  a    First Vector
 * @param  b    Second Vector
 * @param  size Size of vectors
 * @return      Dot product of a and b, i.e. a^T * b
 */
double dot_vectors(double *a, double *b, size_t size) {
	double retval = 0;
	for (size_t i = 0; i < size; i++) {
		retval += a[i] * b[i];
	}
	return retval;
}
/**
 * Calculates and returns the element-wise scaled sum of the supplied vectors.
 * This function will not modify the vectors at a or b.  The result will be
 * equivalent to a * x + b.
 *
 * @param  x    Scale factor for a
 * @param  a    First Vector
 * @param  b    Second Vector
 * @param  size Size of the vectors
 * @return      Element-wise sum of a * x and b
 */
double *addx_vectors(double x, double *a, double *b, size_t size) {
	double *retval = malloc(sizeof(double) * size);
	for (size_t i = 0; i < size; i++) {
		retval[i] = x * a[i] + b[i];
	}
	return retval;
}
/**
 * Calculates and returns the element-wise sum of the supplied vectors.  This
 * function will not modify the memory at a or b.
 *
 * @param  a    First vector
 * @param  b    Second vector
 * @param  size Size of the vectors
 * @return      Element-wise sum of a and b
 */
double *add_vectors(double *a, double *b, size_t size) {
	return addx_vectors(1, a, b, size);
}

/**
 * Calculates and returns the pose of the body given its Tait-Bryan angles (roll
 * pitch, and yaw).  This function does not modify the contents of angles.
 *
 * @param  angles	Tait-Bryan angles representing the inertial orientation of
 *                	the camera.
 * @return       	3d vector representing the inertial orientation of the
 *                  camera as a vector relative to the world axis.
 */
double *eulerToPose(double *angles) {
	double *retval = malloc(sizeof(double) * 3);
	retval[0] = sin(angles[2]);
	retval[1] = cos(angles[2]);
	retval[2] = sin(angles[1]);
	return retval;
}

georef_result *sphere_georef(double *loc, double *pose) {
	double r = EARTH_RADIUS + loc[2];	// radius of camera
	return NULL;
}

georef_result *dist_georef(double *position, double *pose, double range) {
	double *l_0 = position;	// row vector pose location
	double *l = pose;

	double *target = addx_vectors(range, l, l_0, 3);

	georef_result *res = malloc(sizeof(georef_result));
	res->lat = target[0];
	res->lon = target[1];
	res->alt = target[2];

	free(target);
	return res;
}

/**
 * [UTM_georef description]
 *
 * @param  position   [description]
 * @param  pose       [description]
 * @param  target_alt [description]
 * @return            [description]
 */
georef_result *UTM_georef(double *position, double *pose,
                          double target_alt) {
	double *p_0 = calloc(0, sizeof(double) * 3);	// row vector plane point
	p_0[2] = target_alt;

	double *n = calloc(0, sizeof(double) * 3);	// row vector plane normal
	n[2] = 1;

	double *l = pose;	// row vector pose

	double *l_0 = position;	// row vector pose location
	l_0[2] = position[2];

	double *temp = addx_vectors(-1, l_0, p_0, 3);
	double temp1 = dot_vectors(temp, n, 3);
	double ln = dot_vectors(l, n, 3);
	if (ln < 1e-7) {
		return NULL;
	}
	double d = temp1 / ln;

	if (d < 0) {
		return NULL;
	}

	free(temp);

	temp = addx_vectors(d, l, l_0, 3);

	georef_result *res = malloc(sizeof(georef_result));
	res->lat = temp[0];
	res->lon = temp[1];
	res->alt = -temp[2];

	free(p_0);
	free(n);
	free(l_0);
	free(temp);
	return res;
}

georef_result *flat_alt_georef(double camera_alt, double *pose,
                               double target_alt) {
	double *p_0 = calloc(0, sizeof(double) * 3);	// row vector plane point
	p_0[2] = target_alt;

	double *n = calloc(0, sizeof(double) * 3);	// row vector plane normal
	n[2] = 1;

	double *l = pose;	// row vector pose

	double *l_0 = calloc(0, sizeof(double) * 3);	// row vector pose location
	l_0[2] = camera_alt;

	double *temp = addx_vectors(-1, l_0, p_0, 3);
	double temp1 = dot_vectors(temp, n, 3);
	double ln = dot_vectors(l, n, 3);
	if (ln < 1e-7) {
		return NULL;
	}
	double d = temp1 / ln;

	if (d < 0) {
		return NULL;
	}

	free(temp);

	temp = addx_vectors(d, l, l_0, 3);

	georef_result *res = malloc(sizeof(georef_result));
	res->lat = temp[0];
	res->lon = temp[1];
	res->alt = temp[2];

	free(p_0);
	free(n);
	free(l_0);
	free(temp);
	return res;
}

/**
 * flat_georef calculates the view target given a camera pose and altitude.  The
 * target is given in relative xy coordinates, and altitude relative to the
 * same reference as the camera altitude uses.  flat_georef assumes that there
 * is no terrain change between the target and the camera; as a result, the
 * target will always have an altitude of 0 or nan (when the pose is parallel to
 * the ground).  Executing this function will not modify the contents of pose.
 *
 * @param  alt  Altitude of camera
 * @param  pose Vector describing the pose of the camera using an NED frame
 * @return      georef_result struct containing the calculated target location.
 */
georef_result *flat_georef(double alt, double *pose) {
	double *p_0 = calloc(0, sizeof(double) * 3);	// row vector plane point
	double *n = calloc(0, sizeof(double) * 3);	// row vector plane normal
	n[2] = 1;

	double *l = pose;	// row vector pose

	double *l_0 = calloc(0, sizeof(double) * 3);	// row vector pose location
	l_0[2] = alt;

	double *temp = addx_vectors(-1, l_0, p_0, 3);
	double temp1 = dot_vectors(temp, n, 3);
	double ln = dot_vectors(l, n, 3);
	double d = temp1 / ln;

	free(temp);

	temp = addx_vectors(d, l, l_0, 3);

	georef_result *res = malloc(sizeof(georef_result));
	res->lat = temp[0];
	res->lon = temp[1];
	res->alt = temp[2];

	free(p_0);
	free(n);
	free(l_0);
	free(temp);
	return res;
}

/**
 * Converts a 3-d representation of Euler Angles (Tait-Bryan angle) of r, p, y
 * to the equivalent Direct Cosine Matrix representation using a x-y'-z"
 * composition.  The resulting DCM representation represents the body in the
 * world coordinate frame, with the first index being the row index.
 *
 * @param  euler A double array with three elements containing the roll, pitch
 *               and yaw components of the Euler Angle representation
 * @return       A two-dimensional array containing the equivalent Direct
 *               Cosine Matrix representation of the given Euler Angle
 *               representation using a x-y'-z"
 */
double **eulerToDCM(double *euler) {
	double **DCM = malloc(sizeof(double *) * 3);
	double roll = euler[0];
	double pitch = euler[1];
	double yaw = euler[2];

	DCM[0] = malloc(sizeof(double) * 3);
	DCM[0][0] = cos(pitch) * cos(yaw);
	DCM[0][1] = -cos(pitch) * sin(yaw);
	DCM[0][2] = sin(pitch);

	DCM[1] = malloc(sizeof(double) * 3);
	DCM[1][0] = cos(roll) * sin(yaw) + sin(roll) * sin(pitch) * cos(yaw);
	DCM[1][1] = cos(roll) * cos(yaw) - sin(roll) * sin(pitch) * sin(yaw);
	DCM[1][2] = -sin(roll) * cos(pitch);

	DCM[2] = malloc(sizeof(double) * 3);
	DCM[2][1] = sin(roll) * sin(yaw) - cos(roll) * sin(pitch) * cos(yaw);
	DCM[2][1] = sin(roll) * cos(yaw) + cos(roll) * sin(pitch) * sin(yaw);
	DCM[2][2] = cos(roll) * cos(pitch);

	return DCM;
}
