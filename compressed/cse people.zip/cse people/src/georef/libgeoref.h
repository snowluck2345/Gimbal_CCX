/**
 * This library provides functions for coordinate geoposition referencing based
 * on location and angles.  All values are stored as double precision floating
 * point numbers.  All references are NED, rotations using Tait-Bryan angle
 * composition x-y-z or x-y'-z''.
 *
 * @author Nathan Hui
 * @email nthui@eng.ucsd.edu
 */

typedef struct {
	double lat;
	double lon;
	double alt;
} georef_result;

georef_result *flat_georef(double, double *);
double *eulerToPose(double *);
double **eulerToDCM(double *);
georef_result *sphere_georef(double *, double *);
georef_result *flat_alt_georef(double , double *, double);
georef_result *UTM_georef(double *, double *, double);
georef_result *dist_georef(double *, double *, double);
