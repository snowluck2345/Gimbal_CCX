# Telemetry Manager
This is the directory for the Telemetry Manager module.  The Telemetry Manager
is responsible for collecting and packaging telemetry data from the LRF (Laser
RangeFinder) and IMU (Inertial Measurement Unit).  This will allow the
post-processing software to match each data frame with a particular orientation
and photo, if one exists.

# Module Structure
This module is meant to be used as a standalone service.  It provides functions
that initiate data aggregation.

# Software Dependencies
* Python numpy library

# Hardware Dependencies
* MicroStrain 3dm-gx3-25

# Installation
Install all dependencies:

For Debian/Debian derivatives:

    sudo add-apt-repository ppa:scipy/ppa
    sudo apt-get update
    sudo apt-get install python-numpy

# Running
This module is not meant to run as a standalone program.  Use the following code
to integrate:
    import tlm_mgr # Import the tlm_mgr module
    tlm_mgr.start() # start the tlm_mgr server

To interact with this module, use the queue_data() function to queue data for
writing.  Use the stop() function to stop the module before exiting, and to
ensure that the data has been properly written.  Neither of these functions
return anything

Use the check_imu() function to check whether or not the IMU is moving.  This
function is non-blocking, and returns True if the IMU is still, and False if the
IMU is not still.
