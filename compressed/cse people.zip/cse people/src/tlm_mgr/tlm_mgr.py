#!/usr/bin/env python
from collections import namedtuple
from threading import Thread
from time import sleep

import Queue
import serial
import time
import datetime
import sys
import microstrainServer
import numpy

DataStruct = namedtuple("DataStruct", "range pitch yaw time")
THRESHOLD = 0.01

#
# Data structs come in from the left, push out right
def queue_data():
	global lrf

	lrf.flushInput()
	line = lrf.readline()
	dist = line.lstrip(' ').split(' ')[0]
	imu = parse_uStrain()
	struct = DataStruct(dist, imu[0], imu[1], int(time.time() * 1000));
	queue.put(struct)
	return

def check_imu():
	previmu = parse_uStrain()	#get IMU
	prevtime = int(time.time() * 1000)	# time in ms immediately after IMU call
	sleep(0.05)
	curimu = parse_uStrain()	#get IMU
	curtime = int(time.time() * 1000)	# time in ms immediately after IMU call
	dtime = (curtime - prevtime)/1000
	yawspeed = (curimu[1] - previmu[1]) / dtime
	pitchspeed = (curimu[0] - previmu[0]) / dtime
	if abs(yawspeed) < THRESHOLD and abs(pitchspeed) < THRESHOLD:
		return True
	else:
		return False


def parse_imu():
	if run_state == False:
		raise RuntimeError('Module already stopped!)')

	imu.flushInput()
	imu_data = imu.readLine().strip('!* ').split(',')
	pitch = 0
	yaw = 0
	for imu_str in imu_data:
		msg_type = imu_str.split(':')[0]
		msg_data = imu_str.split(':')[1]
		if msg_type == 'PCH':
			pitch = float(msg_data)
		if msg_type == 'YAW':
			yaw = float(msg_data)
		retval = []
		retval[0] = pitch
		retval[1] = yaw
		return retval

def parse_uStrain():
		imu = microstrainServer.get_data()
		q0 = imu[0]
		q1 = imu[1]
		q2 = imu[2]
		q3 = imu[3]
		pitch = numpy.arcsin(2 * (q0 * q2 - q3 * q1))
		yaw = numpy.arctan2(2 * ( q0 * q3 + q1 * q2), 1 - 2 * (q2 * q2 + q3 * q3))
		retval = []
		retval.append(pitch)
		retval.append(yaw)
		return retval

def start():
	global dataFile
	global queue
	global thread
	global run_state

	# Setting up run state
	#dataFile = datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '.txt'
	dataFile = 'out.txt'
	queue = Queue.Queue()
	start_imu()
	start_lrf()

	# Initializing module
	run_state = True
	thread = Thread(target = thread_method, args = ())
	thread.start()
	return

def start_lrf():
	global lrf
	try:
		lrf = serial.Serial('/dev/ttyUSB0', baudrate=115200)
	except serial.SerialException, e:
		print "Error: could not access the laser rangefinder!  Exiting..."
		sys.exit(1)
	except OSError:
		print "Error: could not access the laser rangefinder!  Exiting..."
		sys.exit(1)

def stop_lrf():
	global lrf

def stop_imu():
	global uStrain_thread
	microstrainServer.stop_uStrain()
	uStrain_thread.join()


def start_imu():
	#global imu
	global uStrain_thread
	uStrain_thread = Thread(target = microstrainServer.start_uStrain, args = ())
	uStrain_thread.start()

def stop():
	global dataFile
	global run_state
	global thread

	# Disable queuing
	run_state = False

	# Stop sensors
	stop_imu()
	stop_lrf()

	# Stop module
	thread.join()
	return

def thread_method():
	global run_state
	global dataFile
	global queue

	while run_state == True or not(queue.empty()):
		if not(queue.empty()):
			# process
			struct = queue.get()
			# Write struct to file
			dfile = open(dataFile, 'a')
			dfile.write(str(struct.range) + "\t" + str(struct.pitch) + "\t" + str(struct.yaw) + "\t" + str(struct.time) + "\n")
			dfile.close()
		else:
			# sleep
			time.sleep(1);
