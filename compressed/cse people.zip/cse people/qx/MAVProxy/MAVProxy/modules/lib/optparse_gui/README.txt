This is optparse_gui from http://code.google.com/p/optparse-gui/

Thanks to slider for a great library!
