'''MAVProxy MAVLink ground station libraries'''
