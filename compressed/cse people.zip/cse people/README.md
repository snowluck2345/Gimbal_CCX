Welcome to the CAVECamX GitHub repo!

# Dependencies
* Python numpy
