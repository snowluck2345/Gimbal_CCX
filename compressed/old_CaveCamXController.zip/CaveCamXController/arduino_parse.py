#----------------------------------------------------------------------------
# Title         : arduino_parse.py
# Descritpion	: Parses arduino coms and packet management
# Environment   : Python 2.7
# Author        : Dimitri Schreiber
#----------------------------------------------------------------------------

import time
import math
import serial
import re
import csv
import pynmea2


def move(yaw,yawspeed,pitch,pitchspeed, camera1, camera2):
	arduino_serial.write('nn,%04i,%s,%04i,%s,%s,%s,%s,%s,%s,%s,qq'%(yaw,yawspeed,pitch,pitchspeed, camera1[0], camera1[1], camera1[2], camera2[0], camera2[1], camera2[2]))


arduino_serial = serial.Serial('/dev/cu.usbserial-A6008e6L', baudrate = 57600)


#a = time.clock()


#oldtime = time.clock()
#b = time.clock()
#count = 0

#print time.clock() - oldtime
#oldtime = time.clock()

#mody to read kube, instead of bit by bit, i think that will be cleaner

list_good_packet = []


temp = ''
arduino_buffer = ''
arduino_state = 0
string_state = 0
good_packet = 0

move(0,'0030',0,'0015',camera1, camera1)

while good_packet < 1000:
	#count = count + 1
	while arduino_serial.inWaiting() > 0 and good_packet < 1000:
		#print time.clock() - oldtime
		#oldtime = time.clock()
		old_temp = temp
		temp = arduino_serial.read(1)

		#packet logic: two states, read/not read, parse/notparse
		#if start bit received, start building string
		#if end bit received, stop building string and parse to struct, delete string
		#if start bit received, and another start bit, string never flushed
		if temp == 'n' and old_temp == 'n':
			arduino_state = 1
			arduino_buffer = ''
		elif temp == 'q' and old_temp == 'q':
			arduino_state = 0
			string_state = 1
		elif arduino_state == 1:
			arduino_buffer = arduino_buffer + temp
		elif string_state == 1:
			string_state = 0
			split_response = re.split(',',arduino_buffer)
			if len(split_response) == 16:
				full_IMU_packet = split_response
				list_good_packet.append(full_IMU_packet)
				good_packet = good_packet + 1
				print full_IMU_packet
				#print full_IMU_packet
			arduino_buffer = ''


#c = time.clock()

#print count

#print a
#print b
#print c

#print list_good_packet
print full_IMU_packet

arduino_serial.close()


