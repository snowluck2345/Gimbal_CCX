#----------------------------------------------------------------------------
# Title         : gps_test.py
# Descritpion	: Grabs GPS position / time info, parses it nicely, safe if gps not connected
# Environment   : Python 2.7
# Author        : Dimitri Schreiber
#----------------------------------------------------------------------------

import serial
import pynmea2
import re
import csv


s = serial.Serial('/dev/tty.usbserial-AL008IGL', baudrate = 9600, timeout = 1)

#s.append()
#planned file format:
#gps location
#picture name, encoder yaw, encoder pitch, magnetometer yaw, magnetometer pitch, accelerometer X, accelerometer Y, accelerometer Z
gps_packet = 0

while gps_packet < 1:
	temp = s.readline()
	tempType = re.split(',', temp)[0]
#	print temp
	if tempType == '$GPGGA':
		tempParsed = pynmea2.parse(temp)

		timestamp = tempParsed.timestamp 
		lat = tempParsed.lat
		lat_dir = tempParsed.lat_dir
		lon = tempParsed.lon
		lon_dir = tempParsed.lon_dir
		altitude = tempParsed.altitude
		altitude_units = tempParsed.altitude_units

		if tempParsed.timestamp == '':
			#print'0'
			timestamp = '0'
		if tempParsed.lat == '':
			#print'0'
			lat = '0'
		if tempParsed.lat_dir == '':
			#print'0'
			lat_dir = '0'
		if tempParsed.lon == '':
			#print'0'
			lon = '0'
		if tempParsed.lon_dir == '':
			#print'0'
			lon_dir = '0'
		if tempParsed.altitude == '':
			#print'0'
			altitude = '0'
		if tempParsed.altitude_units == '':
			#print'0'
			altitude_units = '0'

		gps_info = 'Time=%s,Lat=%s%c,Lon=%s%c,Alt=%s%c' % (timestamp,lat,
			lat_dir,lon,lon_dir, altitude, altitude_units)
		print gps_info
		gps_packet = gps_packet + 1

s.close()
		


