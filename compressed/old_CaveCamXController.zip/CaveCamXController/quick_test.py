import serial
import pynmea2
import re

#https://github.com/Knio/pynmea2

test = '$GPGGA,032039.00,3252.02864,N,11713.19160,W,1,08,1.14,87.8,M,-33.8,M,,*5F'
a=pynmea2.parse(test)
print a.timestamp
print a.lat
print a.lat_dir
print a.lon
print a.lon_dir
print a.altitude
print a.altitude_units

b = 'Time=%s,Lat=%s%c,Lon=%s%c,Alt=%s%c' % (a.timestamp,a.lat,a.lat_dir,a.lon,a.lon_dir, a.altitude, a.altitude_units)
print b