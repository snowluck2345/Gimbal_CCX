#----------------------------------------------------------------------------
# Title         : CCX_Main.py
# Descritpion	: Controls CAVECAMX gimbal, geotags
# Environment   : Python 2.7
# Author        : Dimitri Schreiber
#----------------------------------------------------------------------------
#features to add:
#focus stacking, onboard stitching, person detection and reshoot, save outputs to CSV file, annotated with people


import time
import math
import cv2
import serial
import re
from sc_SonyQX1 import SmartCamera_SonyQX

#-----------------------------------------------------------
#gimbal control
#-----------------------------------------------------------
def move(yaw,yawspeed,pitch,pitchspeed, camera1, camera2):
	s.write('nn,%04i,%s,%04i,%s,%s,%s,%s,%s,%s,%s,qq'%(yaw,yawspeed,pitch,pitchspeed, camera1[0], camera1[1], camera1[2], camera2[0], camera2[1], camera2[2]))

#-----------------------------------------------------------
#camera setup
#-----------------------------------------------------------
new_camera = SmartCamera_SonyQX(1,"wlan0")
new_camera.boSetExposureMode("Program Auto")
new_camera.take_picture()
new_camera.get_latest_image()
new_camera.boSetFocusMode("MF")
time.sleep(2)


#-----------------------------------------------------------
#gimbal setup
#-----------------------------------------------------------
s = serial.Serial('/dev/tty.CaveCamX-DevB', baudrate = 57600, timeout = 1)

time.sleep(1)
camera1 = []
camera2 = []
camera1.append(0)
camera1.append(0)
camera1.append(1)
time.sleep(1)

move(0,'0030',0,'0015',camera1, camera1)
c = s.read(1000)
time.sleep(1)

for a in range (0,4050,340):
	for b in range(0,2200,340):
		move(b,'0040',a,'0020',camera1, camera1)
		time.sleep(2)
		out = ''
		while s.inWaiting() > 0:
			out = out +  s.read(1)

		move(b,'0040',a,'0020',camera1, camera1)
		time.sleep(1)
		out = ''
		while s.inWaiting() > 0:
			out = out +  s.read(1)

		#print repr(out)

		#gimbal_command_received = out[11:49]
		#temp = re.split(r'\n', out)
		#dynamixel_info = temp[12:-1]

		#print dynamixel_info

		#pitch_encoder_pos = re.split(r'\r', dynamixel_info[2])[0]
		#pitch_velocity = re.split(r'\r', dynamixel_info[3])[0]
		#yaw_encoder_pos = re.split(r'\r', dynamixel_info[7])[0]
		#yaw_velocity = re.split(r'\r', dynamixel_info[8])[0]

		#print pitch_encoder_pos
		#print yaw_encoder_pos


		name = new_camera.take_picture()
		name = re.split('/',name)[7]
		name = re.split(r'\?',name)[0]
		print name

		photo_info = 'PhotoName=%s' % (name)
		print photo_info

		
