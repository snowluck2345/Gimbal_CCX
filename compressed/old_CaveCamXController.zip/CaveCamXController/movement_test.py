import time
import serial
import re

def move(yaw,yawspeed,pitch,pitchspeed, camera1, camera2):
	s.write('nn,%04i,%s,%04i,%s,%s,%s,%s,%s,%s,%s,qq'%(yaw,yawspeed,pitch,pitchspeed, camera1[0], camera1[1], camera1[2], camera2[0], camera2[1], camera2[2]))

print 'pi'

s = serial.Serial('/dev/tty.CaveCamX-DevB', baudrate = 57600, timeout = 1)


camera1 = []
camera2 = []
camera1.append(0)
camera1.append(0)
camera1.append(1)


#if weird printing issues, I may have funny control characters and I need to be careful what I print
#don't print my binary trash



for a in range (0,4050,340):
	for b in range(0,2200,340):
		move(b,'0040',a,'0020',camera1, camera1)
		time.sleep(2)
		out = ''
		while s.inWaiting() > 0:
			out = out +  s.read(1)

		move(b,'0040',a,'0020',camera1, camera1)
		time.sleep(1)
		out = ''
		while s.inWaiting() > 0:
			out = out +  s.read(1)

		#print repr(out)

		gimbal_command_received = out[11:49]
		temp = re.split(r'\n', out)
		dynamixel_info = temp[12:-1]

		print dynamixel_info

		pitch_encoder_pos = re.split(r'\r', dynamixel_info[2])[0]
		pitch_velocity = re.split(r'\r', dynamixel_info[3])[0]
		yaw_encoder_pos = re.split(r'\r', dynamixel_info[7])[0]
		yaw_velocity = re.split(r'\r', dynamixel_info[8])[0]

		print pitch_encoder_pos
		print yaw_encoder_pos
