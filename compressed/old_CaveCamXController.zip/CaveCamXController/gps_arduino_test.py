#----------------------------------------------------------------------------
# Title         : arduino_parse.py
# Descritpion	: Parses arduino coms and packet management
# Environment   : Python 2.7
# Author        : Dimitri Schreiber
#----------------------------------------------------------------------------

import time
import math
import serial
import re
import csv
import pynmea2



arduino_serial = serial.Serial('/dev/cu.usbserial-A6008e6L', baudrate = 57600)
s = serial.Serial('/dev/tty.usbserial-AL008IGL', baudrate = 9600, timeout = 1)


#a = time.clock()


#oldtime = time.clock()
#b = time.clock()
#count = 0

#print time.clock() - oldtime
#oldtime = time.clock()

#mody to read kube, instead of bit by bit, i think that will be cleaner

list_good_packet = []


#----------------------------------------------------------------------------
#----------------------------------------------------------------------------
#data collection
#----------------------------------------------------------------------------
#----------------------------------------------------------------------------


temp = ''
arduino_buffer = ''
arduino_state = 0
string_state = 0
good_packet_arduino = 0
gps_packet = 0
good_packets = 0

#----------------------------------------------------------------------------
#arduino data grab
#----------------------------------------------------------------------------
while good_packets < 10000:

	good_packet_arduino = 0
	gps_packet = 0
	while good_packet_arduino < 1:
		#count = count + 1
		while arduino_serial.inWaiting() > 0 and good_packet_arduino < 1:
			#print time.clock() - oldtime
			#oldtime = time.clock()
			old_temp = temp
			temp = arduino_serial.read(1)

			#packet logic: two states, read/not read, parse/notparse
			#if start bit received, start building string
			#if end bit received, stop building string and parse to struct, delete string
			#if start bit received, and another start bit, string never flushed
			if temp == 'n' and old_temp == 'n':
				arduino_state = 1
				arduino_buffer = ''
			elif temp == 'q' and old_temp == 'q':
				arduino_state = 0
				string_state = 1
			elif arduino_state == 1:
				arduino_buffer = arduino_buffer + temp
			elif string_state == 1:
				string_state = 0
				split_response = re.split(',',arduino_buffer)
				if len(split_response) == 16:
					full_IMU_packet = split_response
					list_good_packet.append(full_IMU_packet)
					good_packet_arduino = good_packet_arduino + 1
					#print full_IMU_packet
				arduino_buffer = ''

	#c = time.clock()

	#print count

	#print a
	#print b
	#print c

	#print list_good_packet

	#s.append()
	#planned file format:
	#gps location
	#picture name, encoder yaw, encoder pitch, magnetometer yaw, magnetometer pitch, accelerometer X, accelerometer Y, accelerometer Z

	#----------------------------------------------------------------------------
	#gps data grab
	#----------------------------------------------------------------------------


	while gps_packet < 1:
		temp = s.readline()
		tempType = re.split(',', temp)[0]
	#	print temp
		if tempType == '$GPGGA':
			tempParsed = pynmea2.parse(temp)

			timestamp = tempParsed.timestamp 
			lat = tempParsed.lat
			lat_dir = tempParsed.lat_dir
			lon = tempParsed.lon
			lon_dir = tempParsed.lon_dir
			altitude = tempParsed.altitude
			altitude_units = tempParsed.altitude_units

			if tempParsed.timestamp == '':
				#print'0'
				timestamp = '0'
			if tempParsed.lat == '':
				#print'0'
				lat = '0'
			if tempParsed.lat_dir == '':
				#print'0'
				lat_dir = '0'
			if tempParsed.lon == '':
				#print'0'
				lon = '0'
			if tempParsed.lon_dir == '':
				#print'0'
				lon_dir = '0'
			if tempParsed.altitude == '':
				#print'0'
				altitude = '0'
			if tempParsed.altitude_units == '':
				#print'0'
				altitude_units = '0'

			gps_info = 'Time=%s,Lat=%s%c,Lon=%s%c,Alt=%s%c' % (timestamp,lat,
				lat_dir,lon,lon_dir, altitude, altitude_units)
			#print gps_info
			gps_packet = gps_packet + 1

	gimbal_info = 'Ax=%s,Ay=%s,Az=%s,Gx=%s,Gy=%s,Gz=%s,Mx=%s,My=%s,Mz=%s,TiltHeading=%s,Heading=%s' % (full_IMU_packet[3],full_IMU_packet[4],full_IMU_packet[5],full_IMU_packet[6],full_IMU_packet[7],full_IMU_packet[8],full_IMU_packet[9],full_IMU_packet[10],full_IMU_packet[11],full_IMU_packet[12],full_IMU_packet[13])

	print gps_info + ',' + gimbal_info

	good_packets = good_packets + 1




s.close()
arduino_serial.close()

		


