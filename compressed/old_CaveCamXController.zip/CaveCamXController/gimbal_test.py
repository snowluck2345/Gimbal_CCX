#gimbal_test.py

import time
import math
import cv2
import serial
import re
from sc_SonyQX1 import SmartCamera_SonyQX

#-----------------------------------------------------------
#gimbal control
#-----------------------------------------------------------
def move(yaw,yawspeed,pitch,pitchspeed, camera1, camera2):
	arduino_serial.write('nn,%04i,%s,%04i,%s,%s,%s,%s,%s,%s,%s,qq'%(yaw,yawspeed,pitch,pitchspeed, camera1[0], camera1[1], camera1[2], camera2[0], camera2[1], camera2[2]))
#-----------------------------------------------------------
#gimbal setup
#-----------------------------------------------------------
arduino_serial = serial.Serial('/dev/tty.CaveCamX-DevB', baudrate = 57600, timeout = 1)

time.sleep(1)
camera1 = []
camera2 = []
camera1.append(0)
camera1.append(0)
camera1.append(1)
time.sleep(1)


list_good_packet = []

#-----------------------------------------------------------
#parse setup
#-----------------------------------------------------------
temp = ''
arduino_buffer = ''
arduino_state = 0
string_state = 0
good_packet = 0


move(0,'0030',0,'0015',camera1, camera1)
c = arduino_serial.read(1000)
time.sleep(1)

for a in range (0,4050,340):
	for b in range(0,2200,340):
		move(b,'0040',a,'0020',camera1, camera1)
		time.sleep(1.5)

		out = ''
		while arduino_serial.inWaiting() > 0 and good_packet < 1:
			#print time.clock() d- oldtime
			#oldtime = time.clock()
			old_temp = temp
			temp = arduino_serial.read(1)

			#packet logic: two states, read/not read, parse/notparse
			#if start bit received, start building string
			#if end bit received, stop building string and parse to struct, delete string
			#if start bit received, and another start bit, string never flushed
			if temp == 'n' and old_temp == 'n':
				arduino_state = 1
				arduino_buffer = ''
			elif temp == 'q' and old_temp == 'q':
				arduino_state = 0
				string_state = 1
			elif arduino_state == 1:
				arduino_buffer = arduino_buffer + temp
			elif string_state == 1:
				string_state = 0
				split_response = re.split(',',arduino_buffer)
				if len(split_response) == 28:
					full_IMU_packet = split_response
					list_good_packet.append(full_IMU_packet)
					good_packet = good_packet + 1
					print full_IMU_packet
					#print full_IMU_packet
				arduino_buffer = ''

		good_packet = 0

