import time
import math
import cv2
import serial
import re
import csv
from sc_SonyQX1 import SmartCamera_SonyQX

photo_info_array = [[5 for x in range(11)] for x in range(6)]
print photo_info_array

with open("output.csv", "wb") as f:
	writer = csv.writer(f)
	writer.writerows(photo_info_array)
