#include <stdio.h>
#include <stddef.h>
#include <time.h>
#define PIN 67
int main (){
// file handles
FILE
* ofp_export;
FILE
* ofp_gpio67_value;
FILE
* ofp_gpio67_direction;
// export gpio pin for use
ofp_export = fopen("/sys/class/gpio/export", "w");
if(ofp_export == NULL){
printf("Unable to open export.\n");
return -1;
}
fseek(ofp_export, 0, SEEK_SET); // seek to beginning of file
fprintf(ofp_export, "%d", PIN); // write the pin number to export
fflush(ofp_export); // finish writing file
// configure gpio for writing
ofp_gpio67_direction = fopen("/sys/class/gpio/gpio67/direction", "w");
if(ofp_gpio67_direction==NULL){
printf("Unable to open gpio67_direction.\n");
return -1;
}
fseek(ofp_gpio67_direction, 0, SEEK_SET); // seek to beginning of file
fprintf(ofp_gpio67_direction, "out"); // configure as output pin
fflush(ofp_gpio67_direction); // write file
// Open file pointer for writing the value
ofp_gpio67_value = fopen("/sys/class/gpio/gpio67/value", "w");
if(ofp_gpio67_value == NULL){
printf("Unable to open gpio67_value.\n");
return -1;
}
fseek(ofp_gpio67_value, 0, SEEK_SET);
// start blinking loop
printf("blinking LED\n");
Page 17
int i = 0;
while(i<10){
// turn pin on
fprintf(ofp_gpio67_value, "%d", 1);
fflush(ofp_gpio67_value);
printf("ON\n");
sleep(1);
// turn pin off
fprintf(ofp_gpio67_value, "%d", 0);
fflush(ofp_gpio67_value);
printf("OFF\n");
i++; // increment counter
sleep(1);
}
//close all files
fclose(ofp_export);
fclose(ofp_gpio67_direction);
fclose(ofp_gpio67_value);
return 1;
}