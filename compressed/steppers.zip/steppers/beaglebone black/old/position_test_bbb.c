#include <robotics_cape.h>
#define PIN_YAW_PULSE 67
#define PIN_YAW_DIRECTION 66
#define PIN_PITCH_PULSE 67
#define PIN_PITCH_DIRECTION 67
#define ACCELERATION_CONSTANT_YAW 1
#define ACCELERATION_CONSTANT_PITCH 2
#define STEP_SIZE 0.00392699081


int setup_gpio(void);
int micro_acceleration_delay(double step_theta, double acceleration_constant, int step_number);
void calculate_steps_to_move(int32_t *goal_position_cpy, int32_t *current_position_cpy);
void step_yaw(bool direction);
void step_pitch(bool direction);

int32_t goal_position[2]; //pan, tilt
int32_t current_position[2]; //pan, tilt
int32_t steps_to_move[2]; //pan, tilt; negative or positive to determine direction-->negative=cc, postive=c


int main()
{

goal_position[0] = 0;
goal_position[1] = 0;
current_position[0] = 0;
current_position[1] = 0;

goal_position[0] = 0;

int gpio_enabled_success = setup_gpio();

	while(true)
	{

/*		if(current_position[1] != goal_position[1])
		{
			if(steps_to_move[1] > 0)
			{
				step_pitch(1);
				current_position[1]++;		
			}
			if(steps_to_move[1] < 0)
			{
				step_pitch(0);
				current_position[1]--;	
			}
			
		}
*/
		if(current_position[0] != goal_position[0])
		{
			if(steps_to_move[0] > 0)
			{
				step_yaw(1);
				current_position[0]++;		
			}
			if(steps_to_move[0] < 0)
			{
				step_yaw(0);
				current_position[0]--;	
			}
			
			if(current_position[0] < 0)
				current_position[0] = 1600 + current_position[0];
			if(current_position[0] > 1600)
				current_position[0] = current_position[0] - 1600;
				
			//delay_ms(30);
		}

	}
}

int setup_gpio(void)
{
	// export gpio pin for use
if(gpio_export(PIN_YAW_PULSE) || gpio_export(PIN_YAW_DIRECTION) || gpio_export(PIN_PITCH_PULSE) || gpio_export(PIN_PITCH_DIRECTION)){
	printf("Unable to open export.\n");
	return -1;
}

// set pin for output
if(gpio_set_dir(PIN_YAW_PULSE, OUTPUT_PIN) || gpio_set_dir(PIN_YAW_DIRECTION, OUTPUT_PIN) || gpio_set_dir(PIN_PITCH_PULSE, OUTPUT_PIN) || gpio_set_dir(PIN_PITCH_DIRECTION, OUTPUT_PIN)){
	printf("Unable to open gpio67_direction.\n");
	return -1;
}
}


int micro_acceleration_delay(double step_theta, double acceleration_constant, int step_number)
{
	//step_theta is theta per step or microstep
	//acceleration constant is radians/s^2
	//step_number is delay calculation for the step I am interested in calculating

	double delay_seconds = sqrt(2*step_theta/acceleration_constant) * (sqrt(step_number + 1) - sqrt(step_number));
	int delay_microseconds = (int)(delay_seconds * 1000000);

	return delay_microseconds;
}

void calculate_steps_to_move(int32_t *goal_position_cpy, int32_t *current_position_cpy)
{
	steps_to_move[0] = goal_position_cpy[0] - current_position_cpy[0];
	if(steps_to_move[0] > 800)
	{
		steps_to_move[0] = steps_to_move[0] - 160;
	}
	if(steps_to_move[0] < -800)
	{
		steps_to_move[0] = steps_to_move[0] + 1600;
	}
	
	steps_to_move[1] = goal_position_cpy[1] - current_position_cpy[1];
	
}

void step_yaw(bool direction)
{
	//step yaw for 0, pitch for 1
	//implement later
	//reset delay counter in here and do checking if i should actually step--> make sure the delay has been long enough
	
	//yaw
	gpio_set_value(PIN_YAW_DIRECTION, (int)direction);
	gpio_set_value(PIN_YAW_PULSE, 1);
	usleep(100);
	gpio_set_value(PIN_YAW_PULSE, 0);
	
	
}

void step_pitch(bool direction)
{
	//step yaw for 0, pitch for 1
	//implement later
	//reset delay counter in here and do checking if i should actually step--> make sure the delay has been long enough
	
	//yaw
	gpio_set_value(PIN_PITCH_DIRECTION, (int)direction);
	gpio_set_value(PIN_PITCH_PULSE, 1);
	usleep(100);
	gpio_set_value(PIN_PITCH_PULSE, 0);
	
}
