// acceleration test with led
// illuminates an LED connected to a gpio pin with gpio library functions
// use expansion header P8, pin8
// GPIO2_3 designated as gpio 67
#include <robotics_cape.h>
#define PIN 67
#define PIN2 66
#define ACCELERATION_CONSTANT_YAW 3.5
#define ACCELERATION_CONSTANT_PITCH 2
#define STEP_SIZE_YAW 0.00785398163 //radians

int micro_acceleration_delay(double step_theta, double acceleration_constant, int step_number);

int main (void){

// export gpio pin for use
if(gpio_export(PIN)){
	printf("Unable to open export.\n");
	return -1;
}

// set pin for output
if(gpio_set_dir(PIN, OUTPUT_PIN)){
	printf("Unable to open gpio67_direction.\n");
	return -1;
}

if(gpio_export(PIN2)){
	printf("Unable to open export.\n");
	return -1;
}

// set pin for output
if(gpio_set_dir(PIN2, OUTPUT_PIN)){
	printf("Unable to open gpio67_direction.\n");
	return -1;
}

int direction = 0;
// start blinking loop
printf("blinking LED\n");
while(true)
{

gpio_set_value(PIN2, direction);
direction++;
direction = direction % 2;

int i = 0;
while(i<200){
	int delay = micro_acceleration_delay(STEP_SIZE_YAW, ACCELERATION_CONSTANT_YAW, i);

	//8 micro steps 635

	if (delay < 1000)
		delay = 1000;
	printf("%d\n", delay);

	// turn pin on
	gpio_set_value(PIN, 1);
//	printf("ON\n");
	usleep(delay);
	// turn pin off
	gpio_set_value(PIN, 0);
//	printf("OFF\n");
	i++; // increment counter
	usleep(50);
}

while(i>0){
	int delay = micro_acceleration_delay(STEP_SIZE_YAW, ACCELERATION_CONSTANT_YAW, i);

	if (delay < 625)
		delay = 625;
	printf("%d\n", delay);

	// turn pin on
	gpio_set_value(PIN, 1);
//	printf("ON\n");
	usleep(delay);
	// turn pin off
	gpio_set_value(PIN, 0);
//	printf("OFF\n");
	i--; // increment counter
	usleep(50);
}

sleep(3);
}
return 1;
}


int micro_acceleration_delay(double step_theta, double acceleration_constant, int step_number)
{
	//step_theta is theta per step or microstep
	//acceleration constant is radians/s^2
	//step_number is delay calculation for the step I am interested in calculating

	double delay_seconds = sqrt(2*step_theta/acceleration_constant) * (sqrt(step_number + 1) - sqrt(step_number));
	int delay_microseconds = (int)(delay_seconds * 1000000);

	return delay_microseconds;
}