/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to system_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
#include <asf.h>



void configure_port_pins(void)
{
	//configure outputs
	struct port_config config_port_pin;
	
	port_get_config_defaults(&config_port_pin);
	
	config_port_pin.input_pull = PORT_PIN_PULL_DOWN;
	config_port_pin.direction = PORT_PIN_DIR_OUTPUT;
	
	port_pin_set_config(PIN_PA28, &config_port_pin);//led pin
	port_pin_set_config(PIN_PA18, &config_port_pin);//yaw, pin 5 EXT1
	port_pin_set_config(PIN_PA19, &config_port_pin);//yaw, pin 6 EXT1
	port_pin_set_config(PIN_PA22, &config_port_pin);//pitch, pin 5 EXT2
	port_pin_set_config(PIN_PA23, &config_port_pin);//pitch, pin 6 EXT2
	//	port_pin_set_config(PIN_PB30, &config_port_pin);//trigger camera
	
}

int main (void)
{
	
	system_init();
	delay_init();
	configure_port_pins();
	
	port_pin_set_output_level(PIN_PA28, true);
	
	while(1)
	{
		port_pin_toggle_output_level(PIN_PA28);
		delay_ms(2000);	
	}

}
