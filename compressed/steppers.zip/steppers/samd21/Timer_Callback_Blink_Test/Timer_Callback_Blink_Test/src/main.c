/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to system_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
#include <asf.h>

/*
XOSC32K should be enabled and available through GCLK generator 1 clock source selection.
Within Atmel Software Framework (ASF) it can be done through modifying conf_clocks.h.
*/

struct tc_module tc_instance;void configure_port_pins(void)
{
	//configure outputs
	struct port_config config_port_pin;
	
	port_get_config_defaults(&config_port_pin);
	
	config_port_pin.input_pull = PORT_PIN_PULL_DOWN;
	config_port_pin.direction = PORT_PIN_DIR_OUTPUT;
	
	port_pin_set_config(PIN_PA28, &config_port_pin);//led pin
	port_pin_set_config(PIN_PA18, &config_port_pin);//yaw, pin 5 EXT1
	port_pin_set_config(PIN_PA19, &config_port_pin);//yaw, pin 6 EXT1
	port_pin_set_config(PIN_PA22, &config_port_pin);//pitch, pin 5 EXT2
	port_pin_set_config(PIN_PA23, &config_port_pin);//pitch, pin 6 EXT2
	//	port_pin_set_config(PIN_PB30, &config_port_pin);//trigger camera
	
}void tc_callback_to_toggle_led(struct tc_module *const module_inst)
{
 port_pin_toggle_output_level(PIN_PA28);

}
void configure_tc(void)
{
 struct tc_config config_tc;
 tc_get_config_defaults(&config_tc);
 config_tc.counter_size = TC_COUNTER_SIZE_8BIT;
 config_tc.clock_source = GCLK_GENERATOR_1;
 config_tc.clock_prescaler = TC_CLOCK_PRESCALER_DIV16;
 config_tc.counter_8_bit.period = 10;

 tc_init(&tc_instance, TC3, &config_tc);
 tc_enable(&tc_instance);
}
void configure_tc_callbacks(void)
{
 tc_register_callback(&tc_instance, tc_callback_to_toggle_led,
 TC_CALLBACK_OVERFLOW);
 
 tc_enable_callback(&tc_instance, TC_CALLBACK_OVERFLOW);
}

void main()
{
	configure_port_pins();
	
	port_pin_set_output_level(PIN_PA28, true);
	
	configure_tc();
	configure_tc_callbacks();
	while(1)
	{
		
	}
	
}